import React, { useEffect, useState } from 'react';
import { Language } from '../types';
import { translations } from '../data/translations';

interface LoadingScreenProps {
  lang: Language;
  onFinish: () => void;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ lang, onFinish }) => {
  const [progress, setProgress] = useState(15);
  const t = translations[lang].loading;

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onFinish, 350);
          return 100;
        }
        return prev + 15;
      });
    }, 180);

    return () => clearInterval(timer);
  }, [onFinish]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#870505] text-stone-100 px-4 sm:px-6 select-none overflow-hidden">
      {/* Background patterned watermark */}
      <div className="absolute inset-0 opacity-10 pointer-events-none bg-[radial-gradient(#F2C14E_1px,transparent_1px)] [background-size:24px_24px]" />

      <div className="relative flex flex-col items-center max-w-sm sm:max-w-md w-full text-center">
        {/* Vintage Seal badge */}
        <div className="mb-3 inline-flex items-center gap-2 border border-[#F2C14E]/60 bg-[#5d0202]/90 px-4 py-1 rounded-sm text-xs font-semibold uppercase tracking-widest text-[#F2C14E] shadow-lg">
          <span className="w-1.5 h-1.5 rounded-full bg-[#F2C14E] animate-ping" />
          Phở Thìn Bờ Hồ • Từ 1955
        </div>

        {/* Authentic Canva Loading Graphic or Steaming Bowl Container */}
        <div className="relative my-3 w-56 sm:w-64 max-h-[320px] rounded-2xl overflow-hidden border-2 border-[#F2C14E]/70 shadow-[0_0_35px_rgba(242,193,78,0.3)] bg-[#5d0202]">
          <img
            src="/news/loading-canva.png"
            onError={(e) => {
              // Fallback to pho bowl image if needed
              (e.target as HTMLImageElement).src = '/src/assets/images/loading_pho_bowl_1790702809711.jpg';
            }}
            alt="Đang tải Phở Thìn Bờ Hồ"
            className="w-full h-auto object-cover max-h-[300px]"
            referrerPolicy="no-referrer"
          />
        </div>

        {/* Brand Title */}
        <h2 className="text-xl sm:text-2xl font-serif font-bold text-[#F2C14E] tracking-tight text-gold-radiant mt-1">
          PHỞ THÌN BỜ HỒ
        </h2>

        {/* Loading status message */}
        <p className="text-xs sm:text-sm font-medium text-stone-200 mt-1 max-w-xs">
          {t.text}
        </p>
        <p className="text-[11px] text-[#F2C14E]/80">
          {t.subtext}
        </p>

        {/* Progress Bar with gold accent */}
        <div className="w-60 h-1.5 bg-[#400101] rounded-full overflow-hidden mt-4 border border-[#F2C14E]/40">
          <div
            className="h-full bg-gradient-to-r from-[#F2C14E] to-[#FFF0A5] transition-all duration-200 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Manual Skip button */}
        <button
          onClick={onFinish}
          className="mt-4 text-xs text-stone-300 hover:text-[#F2C14E] underline decoration-stone-500 hover:decoration-[#F2C14E] transition-colors cursor-pointer"
        >
          {lang === 'vi' ? 'Vào xem trang ngay →' : 'Enter Website Now →'}
        </button>
      </div>
    </div>
  );
};
