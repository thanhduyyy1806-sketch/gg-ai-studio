import React from 'react';
import { Language, PageView } from '../types';
import { translations } from '../data/translations';
import { ArrowRight, BookOpen, Compass, Flame, Sparkles } from 'lucide-react';

interface HomeIntroCardsProps {
  lang: Language;
  onNavigate: (view: PageView) => void;
  onHeadingClick: () => void;
}

export const HomeIntroCards: React.FC<HomeIntroCardsProps> = ({
  lang,
  onNavigate,
  onHeadingClick,
}) => {
  const t = translations[lang].homeCards;

  const cards = [
    {
      id: 'intro',
      title: t.card1Title,
      desc: t.card1Desc,
      icon: BookOpen,
      year: '1955',
    },
    {
      id: 'history',
      title: t.card2Title,
      desc: t.card2Desc,
      icon: Compass,
      year: '70 Năm',
    },
    {
      id: 'origin',
      title: t.card3Title,
      desc: t.card3Desc,
      icon: Flame,
      year: 'Gia Tộc',
    },
    {
      id: 'quintessence',
      title: t.card4Title,
      desc: t.card4Desc,
      icon: Sparkles,
      year: 'Tinh Hoa',
    },
  ];

  const handleCardClick = () => {
    onNavigate('about');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <section className="py-16 sm:py-20 bg-[#870505] text-stone-100 border-b border-[#F2C14E]/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <h2
            onClick={onHeadingClick}
            className="text-2xl sm:text-3xl lg:text-4xl font-serif font-bold text-[#F2C14E] text-gold-radiant cursor-pointer hover:opacity-95 transition-opacity"
            title="Bấm để xem cảnh báo mạo danh & bảo vệ bản quyền"
          >
            {t.title}
          </h2>
          <p className="mt-3 text-sm sm:text-base text-stone-300">
            {t.subtitle}
          </p>
        </div>

        {/* 4 Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {cards.map((card, idx) => {
            const Icon = card.icon;
            return (
              <div
                key={card.id}
                className="group relative bg-[#5d0202] border border-[#F2C14E]/40 hover:border-[#F2C14E] rounded-lg p-6 flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 rounded-full bg-[#870505] border border-[#F2C14E] flex items-center justify-center text-[#F2C14E]">
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-mono font-bold text-[#F2C14E]/80">
                      0{idx + 1} • {card.year}
                    </span>
                  </div>

                  <h3
                    onClick={(e) => {
                      e.stopPropagation();
                      onHeadingClick();
                    }}
                    className="text-lg font-serif font-bold text-[#F2C14E] mb-2 cursor-pointer hover:underline"
                    title="Bấm vào tiêu đề để xem cảnh báo"
                  >
                    {card.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
                    {card.desc}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-stone-700/60">
                  <button
                    onClick={handleCardClick}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#F2C14E] group-hover:text-[#ffe285] transition-colors cursor-pointer"
                  >
                    <span>{t.discoverMore}</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
