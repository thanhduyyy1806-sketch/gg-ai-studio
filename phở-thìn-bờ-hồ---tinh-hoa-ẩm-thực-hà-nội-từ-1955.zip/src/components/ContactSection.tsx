import React, { useState } from 'react';
import { Language, PageView } from '../types';
import { BRANCHES } from '../data/branches';
import { translations } from '../data/translations';
import { 
  MapPin, 
  Phone, 
  Clock, 
  Navigation, 
  Briefcase, 
  ExternalLink, 
  CheckCircle, 
  CalendarCheck, 
  AlertTriangle,
  Building
} from 'lucide-react';

interface ContactSectionProps {
  lang: Language;
  onNavigate: (view: PageView) => void;
  onHeadingClick: () => void;
  onReserveBranch: (branchId: string) => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({
  lang,
  onNavigate,
  onHeadingClick,
  onReserveBranch,
}) => {
  const [activeTab, setActiveTab] = useState<'branches' | 'careers'>('branches');
  const [appliedPosition, setAppliedPosition] = useState<string | null>(null);
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [applicantName, setApplicantName] = useState('');
  const [applicantPhone, setApplicantPhone] = useState('');
  const [applicantSubmitted, setApplicantSubmitted] = useState(false);

  const t = translations[lang].contact;

  const handleApplySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!applicantName || !applicantPhone) return;
    setApplicantSubmitted(true);
    setTimeout(() => {
      setApplicantSubmitted(false);
      setShowApplyModal(false);
      setApplicantName('');
      setApplicantPhone('');
    }, 2500);
  };

  return (
    <div className="py-12 sm:py-16 bg-[#870505] min-h-screen text-stone-100">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-stone-300 mb-6">
          <button
            onClick={() => onNavigate('home')}
            className="hover:text-[#F2C14E] transition-colors cursor-pointer"
          >
            {translations[lang].nav.home}
          </button>
          <span>/</span>
          <span className="text-[#F2C14E] font-medium">{translations[lang].nav.contact}</span>
        </div>

        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <h1
            onClick={onHeadingClick}
            className="text-3xl sm:text-4xl font-serif font-black text-[#F2C14E] text-gold-radiant cursor-pointer hover:opacity-95"
            title="Bấm để xem cảnh báo"
          >
            {t.title}
          </h1>
          <p className="mt-2 text-sm sm:text-base text-stone-300">
            {t.subtitle}
          </p>
        </div>

        {/* Tab Switcher: 4 Cơ Sở vs Tuyển Dụng */}
        <div className="flex items-center justify-center gap-3 mb-10">
          <button
            onClick={() => setActiveTab('branches')}
            className={`px-6 py-2.5 rounded-lg text-xs sm:text-sm font-bold uppercase tracking-wider transition-all cursor-pointer ${
              activeTab === 'branches'
                ? 'bg-[#F2C14E] text-[#1A1A1A] shadow-lg'
                : 'bg-[#5d0202] text-stone-300 border border-[#F2C14E]/40 hover:text-white'
            }`}
          >
            {t.tabBranches}
          </button>
          <button
            onClick={() => setActiveTab('careers')}
            className={`px-6 py-2.5 rounded-lg text-xs sm:text-sm font-bold uppercase tracking-wider transition-all cursor-pointer ${
              activeTab === 'careers'
                ? 'bg-[#F2C14E] text-[#1A1A1A] shadow-lg'
                : 'bg-[#5d0202] text-stone-300 border border-[#F2C14E]/40 hover:text-white'
            }`}
          >
            {t.tabCareers}
          </button>
        </div>

        {/* TAB 1: 4 CƠ SỞ CHÍNH THỨC */}
        {activeTab === 'branches' && (
          <div className="space-y-8">
            <div className="bg-[#5d0202] border border-[#F2C14E]/40 p-4 rounded-xl flex items-center justify-between flex-wrap gap-4 text-xs">
              <div className="flex items-center gap-2 text-[#F2C14E]">
                <Clock className="w-4 h-4 shrink-0" />
                <span className="font-semibold">
                  Khung giờ phục vụ chung: Sáng 06:00 – 13:00 | Chiều 17:00 – 22:00
                </span>
              </div>
              <button
                onClick={onHeadingClick}
                className="text-stone-300 hover:text-[#F2C14E] underline flex items-center gap-1 cursor-pointer"
              >
                <AlertTriangle className="w-3.5 h-3.5 text-[#F2C14E]" />
                <span>Xem cảnh báo ghim vị trí sai lệch</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {BRANCHES.map((b) => (
                <div
                  key={b.id}
                  className={`bg-[#5d0202] rounded-xl p-6 border flex flex-col justify-between transition-all ${
                    b.isOriginal 
                      ? 'border-[#F2C14E] ring-2 ring-[#F2C14E]/30 bg-gradient-to-br from-[#680303] to-[#500202]' 
                      : 'border-[#F2C14E]/30 hover:border-[#F2C14E]'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="px-2 py-0.5 rounded bg-[#870505] border border-[#F2C14E]/40 text-[#F2C14E] text-xs font-mono font-bold">
                        {b.code}
                      </span>
                      {b.isOriginal && (
                        <span className="text-[11px] font-bold bg-[#F2C14E] text-[#1A1A1A] px-2 py-0.5 rounded">
                          CỘI NGUỒN TỪ 1955
                        </span>
                      )}
                    </div>

                    <h3
                      onClick={onHeadingClick}
                      className="text-lg font-serif font-bold text-[#F2C14E] mb-2 cursor-pointer hover:underline"
                    >
                      {b.name[lang]}
                    </h3>

                    <p className="text-xs text-[#F2C14E]/90 italic mb-4">
                      "{b.highlight[lang]}"
                    </p>

                    <div className="space-y-2.5 text-xs text-stone-200">
                      <div className="flex items-start gap-2">
                        <MapPin className="w-4 h-4 text-[#F2C14E] shrink-0 mt-0.5" />
                        <span>{b.address}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-[#F2C14E] shrink-0" />
                        <a
                          href={`tel:${b.phone.replace(/[^0-9+]/g, '')}`}
                          className="font-mono font-bold text-white hover:text-[#F2C14E] hover:underline"
                        >
                          {b.phone}
                        </a>
                      </div>

                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-[#F2C14E] shrink-0" />
                        <span>{b.openingHours}</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions for this specific branch */}
                  <div className="mt-6 pt-4 border-t border-stone-700/60 flex flex-wrap gap-2">
                    <button
                      onClick={() => onReserveBranch(b.id)}
                      className="flex-1 py-2 px-3 bg-[#F2C14E] text-[#1A1A1A] font-bold text-xs uppercase tracking-wider rounded hover:bg-[#ffe380] transition-colors flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <CalendarCheck className="w-3.5 h-3.5 text-[#870505]" />
                      <span>Đặt bàn tại {b.code}</span>
                    </button>

                    <a
                      href={b.googleMapsLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="py-2 px-3 bg-[#400101] hover:bg-[#870505] border border-stone-500 text-stone-200 text-xs font-semibold rounded flex items-center justify-center gap-1 transition-colors"
                    >
                      <Navigation className="w-3.5 h-3.5 text-[#F2C14E]" />
                      <span>{t.btnDirections}</span>
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 2: TUYỂN DỤNG NHÂN SỰ */}
        {activeTab === 'careers' && (
          <div className="bg-[#5d0202] border-2 border-[#F2C14E]/60 rounded-2xl p-6 sm:p-10 shadow-2xl space-y-8">
            <div className="text-center max-w-xl mx-auto">
              <Briefcase className="w-10 h-10 text-[#F2C14E] mx-auto mb-3" />
              <h2
                onClick={onHeadingClick}
                className="text-2xl font-serif font-bold text-[#F2C14E] cursor-pointer hover:underline"
              >
                {t.careersHeading}
              </h2>
              <p className="mt-2 text-xs sm:text-sm text-stone-200">
                {t.careersSub}
              </p>
            </div>

            {/* Positions list */}
            <div>
              <h3 className="text-sm font-bold uppercase tracking-wider text-[#F2C14E] mb-4">
                {t.positionsTitle}
              </h3>

              <div className="space-y-3">
                {[
                  { title: t.pos1, type: 'Full-time / Part-time', salary: '7.500.000 – 9.000.000 đ' },
                  { title: t.pos2, type: 'Học nghề gia truyền', salary: '8.500.000 – 12.000.000 đ' },
                  { title: t.pos3, type: 'Ca xoay linh hoạt', salary: '8.000.000 – 10.000.000 đ' },
                ].map((pos, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl bg-[#400101] border border-[#F2C14E]/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <h4 className="text-sm font-bold text-white">{pos.title}</h4>
                      <div className="flex items-center gap-3 text-xs text-stone-300 mt-1">
                        <span>Hình thức: {pos.type}</span>
                        <span>•</span>
                        <span className="text-[#F2C14E] font-mono font-semibold">Thu nhập: {pos.salary}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setAppliedPosition(pos.title);
                        setShowApplyModal(true);
                      }}
                      className="px-4 py-2 bg-[#870505] hover:bg-[#F2C14E] text-[#F2C14E] hover:text-[#1A1A1A] border border-[#F2C14E] text-xs font-bold uppercase tracking-wider rounded transition-colors cursor-pointer"
                    >
                      Ứng tuyển ngay
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Benefits */}
            <div className="bg-[#420101] p-5 rounded-xl border border-stone-700 space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#F2C14E]">
                {t.benefitsTitle}
              </h4>
              <p className="text-xs sm:text-sm text-stone-200 leading-relaxed">
                {t.benefits}
              </p>
            </div>

            {/* Google Docs link button according to specification */}
            <div className="text-center pt-4">
              <a
                href="https://docs.google.com/forms"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-8 py-3 bg-[#F2C14E] text-[#1A1A1A] font-bold text-xs uppercase tracking-wider rounded shadow-lg hover:bg-[#ffe380] transition-colors"
              >
                <span>{t.btnApplyDocs}</span>
                <ExternalLink className="w-4 h-4 text-[#870505]" />
              </a>
            </div>
          </div>
        )}

        {/* Application Modal Popup */}
        {showApplyModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
            <div className="bg-[#5d0202] border-2 border-[#F2C14E] rounded-xl p-6 max-w-md w-full text-stone-100 shadow-2xl">
              <h3 className="text-lg font-serif font-bold text-[#F2C14E] mb-1">
                Ứng Tuyển: {appliedPosition}
              </h3>
              <p className="text-xs text-stone-300 mb-4">
                Điền nhanh thông tin liên lạc để Bộ phận Nhân sự Phở Thìn Bờ Hồ gọi lại phỏng vấn:
              </p>

              {applicantSubmitted ? (
                <div className="text-center py-6 space-y-2">
                  <CheckCircle className="w-10 h-10 text-[#F2C14E] mx-auto" />
                  <p className="text-sm font-bold text-white">Đã gửi thông tin ứng tuyển thành công!</p>
                  <p className="text-xs text-stone-300">Quán sẽ liên hệ bạn qua điện thoại trong 24 giờ tới.</p>
                </div>
              ) : (
                <form onSubmit={handleApplySubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-[#F2C14E] mb-1">Họ và tên của bạn</label>
                    <input
                      type="text"
                      required
                      value={applicantName}
                      onChange={(e) => setApplicantName(e.target.value)}
                      placeholder="Nguyễn Văn A"
                      className="w-full px-3 py-2 bg-[#400101] border border-[#F2C14E]/40 rounded text-sm text-white focus:outline-none focus:ring-1 focus:ring-[#F2C14E]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#F2C14E] mb-1">Số điện thoại liên hệ</label>
                    <input
                      type="tel"
                      required
                      value={applicantPhone}
                      onChange={(e) => setApplicantPhone(e.target.value)}
                      placeholder="098xxxxxxx"
                      className="w-full px-3 py-2 bg-[#400101] border border-[#F2C14E]/40 rounded text-sm text-white focus:outline-none focus:ring-1 focus:ring-[#F2C14E]"
                    />
                  </div>

                  <div className="flex gap-2 pt-2">
                    <button
                      type="submit"
                      className="flex-1 py-2.5 bg-[#F2C14E] text-[#1A1A1A] font-bold text-xs uppercase tracking-wider rounded hover:bg-[#ffe380] cursor-pointer"
                    >
                      Gửi ứng tuyển
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowApplyModal(false)}
                      className="px-4 py-2.5 bg-stone-700 text-stone-200 text-xs rounded hover:bg-stone-600 cursor-pointer"
                    >
                      Hủy
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
