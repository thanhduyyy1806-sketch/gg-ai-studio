import React from 'react';
import { Language, Dish, PageView } from '../types';
import { DISHES } from '../data/dishes';
import { translations } from '../data/translations';
import { Award, ArrowRight, Utensils } from 'lucide-react';

interface HomeFeaturedDishesProps {
  lang: Language;
  onNavigate: (view: PageView) => void;
  onSelectDish: (dish: Dish) => void;
  onHeadingClick: () => void;
}

export const HomeFeaturedDishes: React.FC<HomeFeaturedDishesProps> = ({
  lang,
  onNavigate,
  onSelectDish,
  onHeadingClick,
}) => {
  const t = translations[lang].featuredDishes;

  // 5 featured dishes with "Phở tái chín" in the middle:
  // Order: [Phở sốt vang, Phở sườn cây đặc biệt, Phở tái chín (CENTER), Phở xào bò, Phở cuốn]
  const orderedDishes = [
    DISHES.find((d) => d.id === 'pho-sot-vang')!,
    DISHES.find((d) => d.id === 'pho-suon-cay')!,
    DISHES.find((d) => d.id === 'pho-tai-chin')!, // CENTER SIGNATURE
    DISHES.find((d) => d.id === 'pho-xao-bo')!,
    DISHES.find((d) => d.id === 'pho-cuon-ha-noi')!,
  ].filter(Boolean);

  return (
    <section className="py-16 sm:py-24 bg-[#5d0202] text-stone-100 border-b border-[#F2C14E]/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-[#870505] border border-[#F2C14E]/60 text-[#F2C14E] text-xs font-semibold uppercase tracking-wider mb-3">
            <Utensils className="w-3.5 h-3.5" />
            <span>Thực Đơn Tinh Hoa 1955</span>
          </div>
          <h2
            onClick={onHeadingClick}
            className="text-2xl sm:text-3xl lg:text-4xl font-serif font-bold text-[#F2C14E] text-gold-radiant cursor-pointer hover:opacity-95 transition-opacity"
            title="Bấm để xem cảnh báo mạo danh & bảo vệ bản quyền"
          >
            {t.title}
          </h2>
          <p className="mt-3 text-sm sm:text-base text-stone-300">
            {t.subtitle}
          </p>
        </div>

        {/* 5 Dishes Showcase Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-5">
          {orderedDishes.map((dish, index) => {
            const isCenterSignature = dish.isSignature; // Phở tái chín at center
            return (
              <div
                key={dish.id}
                onClick={() => onSelectDish(dish)}
                className={`group relative rounded-xl overflow-hidden cursor-pointer flex flex-col justify-between transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl ${
                  isCenterSignature
                    ? 'bg-[#870505] border-2 border-[#F2C14E] ring-4 ring-[#F2C14E]/20 lg:-translate-y-2'
                    : 'bg-[#400101] border border-[#F2C14E]/30 hover:border-[#F2C14E]'
                }`}
              >
                {/* Image top with rounded corners */}
                <div className="relative aspect-4/3 overflow-hidden bg-stone-900">
                  <img
                    src={dish.image}
                    alt={dish.name[lang]}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-80" />

                  {/* SIGNATURE badge strictly on Phở tái chín per instructions */}
                  {dish.isSignature && (
                    <div className="absolute top-3 left-3 bg-[#F2C14E] text-[#1A1A1A] font-black text-[11px] px-2.5 py-1 rounded shadow-lg flex items-center gap-1">
                      <Award className="w-3.5 h-3.5 text-[#870505]" />
                      <span>SIGNATURE</span>
                    </div>
                  )}

                  <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-black/75 border border-[#F2C14E]/50 text-xs font-mono font-bold text-[#F2C14E]">
                    {dish.formattedPrice}đ
                  </div>
                </div>

                {/* Card Body */}
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-base font-serif font-bold text-[#F2C14E] group-hover:text-[#ffe58f] transition-colors leading-snug line-clamp-2">
                      {dish.name[lang]}
                    </h3>

                    {/* Short Description 2-3 lines light on red */}
                    <p className="mt-2 text-xs text-stone-200 line-clamp-3 leading-relaxed">
                      {dish.shortDescription[lang]}
                    </p>
                  </div>

                  {/* Quick view indicator */}
                  <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs text-[#F2C14E]">
                    <span className="font-semibold">{t.viewDetail}</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* CTA Button: [Thực đơn chi tiết] */}
        <div className="mt-14 text-center">
          <button
            onClick={() => onNavigate('menu')}
            className="inline-flex items-center gap-2 px-8 py-3.5 bg-[#F2C14E] text-[#1A1A1A] font-bold text-sm uppercase tracking-wider rounded shadow-lg hover:bg-[#ffe380] transform active:scale-95 transition-all cursor-pointer"
          >
            <span>{t.btnFullMenu}</span>
            <ArrowRight className="w-4 h-4 text-[#870505]" />
          </button>
        </div>
      </div>
    </section>
  );
};
