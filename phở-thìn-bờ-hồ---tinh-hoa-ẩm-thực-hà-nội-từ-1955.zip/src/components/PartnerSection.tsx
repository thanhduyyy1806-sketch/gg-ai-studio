import React from 'react';
import { Language, PageView } from '../types';
import { translations } from '../data/translations';
import { Handshake, Globe, Award, Sparkles, CheckCircle2, ArrowRight } from 'lucide-react';

interface PartnerSectionProps {
  lang: Language;
  onNavigate: (view: PageView) => void;
  onHeadingClick: () => void;
}

export const PartnerSection: React.FC<PartnerSectionProps> = ({
  lang,
  onNavigate,
  onHeadingClick,
}) => {
  const t = translations[lang].partners;

  return (
    <div className="py-12 sm:py-16 bg-[#870505] min-h-screen text-stone-100">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-stone-300 mb-6">
          <button
            onClick={() => onNavigate('home')}
            className="hover:text-[#F2C14E] transition-colors cursor-pointer"
          >
            {translations[lang].nav.home}
          </button>
          <span>/</span>
          <span className="text-[#F2C14E] font-medium">{translations[lang].nav.partners}</span>
        </div>

        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded bg-[#5d0202] border border-[#F2C14E]/60 text-[#F2C14E] text-xs font-semibold uppercase tracking-wider mb-3">
            <Handshake className="w-4 h-4 text-[#F2C14E]" />
            <span>Hợp Tác Chiến Lược</span>
          </div>
          <h1
            onClick={onHeadingClick}
            className="text-3xl sm:text-4xl font-serif font-black text-[#F2C14E] text-gold-radiant cursor-pointer hover:opacity-95"
            title="Bấm để xem cảnh báo giả mạo"
          >
            {t.title}
          </h1>
          <p className="mt-3 text-sm sm:text-base text-stone-300">
            {t.subtitle}
          </p>
        </div>

        {/* Featured Collaboration Card */}
        <div className="bg-[#5d0202] border-2 border-[#F2C14E]/60 rounded-2xl p-6 sm:p-10 shadow-2xl relative overflow-hidden mb-12">
          {/* Subtle watermark */}
          <div className="absolute right-0 bottom-0 opacity-5 pointer-events-none text-9xl font-black font-serif text-[#F2C14E]">
            1955
          </div>

          <div className="relative z-10 grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            {/* Visual Brand Lockup */}
            <div className="md:col-span-5 flex flex-col items-center justify-center p-6 bg-[#400101] rounded-xl border border-[#F2C14E]/40 text-center">
              <div className="flex items-center justify-center gap-4 mb-4">
                <div className="w-16 h-16 rounded-full bg-[#870505] border-2 border-[#F2C14E] flex flex-col items-center justify-center text-[#F2C14E] font-serif font-bold text-xs p-1">
                  <span>PHỞ THÌN</span>
                  <span className="text-[9px] text-stone-300">BỜ HỒ</span>
                  <span className="text-[8px] text-[#F2C14E]">1955</span>
                </div>
                <span className="text-xl font-bold text-[#F2C14E]">✕</span>
                <div className="w-16 h-16 rounded-full bg-red-600 border-2 border-white flex flex-col items-center justify-center text-white font-black text-xs p-1">
                  <span>CHIN-SU</span>
                  <span className="text-[8px] uppercase tracking-tighter">MASAN</span>
                </div>
              </div>

              <span className="text-sm font-serif font-bold text-[#F2C14E] block">
                Dự Án "Phở Story"
              </span>
              <span className="text-xs text-stone-300 mt-1">
                Chuẩn vị phở bò thanh trong Bờ Hồ
              </span>
            </div>

            {/* Description */}
            <div className="md:col-span-7 space-y-4">
              <h2
                onClick={onHeadingClick}
                className="text-xl sm:text-2xl font-serif font-bold text-[#F2C14E] cursor-pointer hover:underline"
              >
                {t.projectTitle}
              </h2>
              <p className="text-xs sm:text-sm text-stone-200 leading-relaxed">
                {t.desc1}
              </p>
              <p className="text-xs sm:text-sm text-stone-200 leading-relaxed">
                {t.desc2}
              </p>

              <div className="pt-2 space-y-2">
                <div className="flex items-center gap-2 text-xs sm:text-sm text-stone-100 font-medium">
                  <CheckCircle2 className="w-4 h-4 text-[#F2C14E] shrink-0" />
                  <span>{t.highlightQuality}</span>
                </div>
                <div className="flex items-center gap-2 text-xs sm:text-sm text-stone-100 font-medium">
                  <Globe className="w-4 h-4 text-[#F2C14E] shrink-0" />
                  <span>{t.highlightReach}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom CTA to Reserve Table or View Menu */}
        <div className="text-center">
          <p className="text-xs sm:text-sm text-stone-300 mb-4">
            {lang === 'vi'
              ? 'Để trải nghiệm trọn vẹn bát phở nóng hổi vừa bốc khói tại chỗ, kính mời quý khách ghé thăm 4 cơ sở chính thức:'
              : 'To experience steaming hot bowls prepared fresh at our hearth, we welcome you to our 4 official branches:'}
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={() => onNavigate('menu')}
              className="px-6 py-2.5 bg-[#5d0202] border border-[#F2C14E] text-[#F2C14E] hover:bg-[#870505] rounded text-xs uppercase font-bold tracking-wider cursor-pointer transition-colors"
            >
              {translations[lang].nav.menu}
            </button>
            <button
              onClick={() => onNavigate('reservation')}
              className="px-6 py-2.5 bg-[#F2C14E] text-[#1A1A1A] hover:bg-[#ffe380] rounded text-xs uppercase font-bold tracking-wider cursor-pointer transition-colors shadow-md"
            >
              {translations[lang].nav.reserve}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
