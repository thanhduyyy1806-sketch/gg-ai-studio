import React from 'react';
import { Dish, Language, PageView } from '../types';
import { DISHES } from '../data/dishes';
import { translations } from '../data/translations';
import { ArrowLeft, CalendarCheck, Award, CheckCircle2, Info } from 'lucide-react';

interface DishDetailModalProps {
  dish: Dish | null;
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onNavigate: (view: PageView) => void;
  onReserveWithDish: (dish: Dish) => void;
  onSelectDish: (dish: Dish) => void;
}

export const DishDetailModal: React.FC<DishDetailModalProps> = ({
  dish,
  isOpen,
  onClose,
  lang,
  onNavigate,
  onReserveWithDish,
  onSelectDish,
}) => {
  if (!isOpen || !dish) return null;

  const t = translations[lang].dishDetail;
  const relatedDishes = DISHES.filter(
    (d) => d.category === dish.category && d.id !== dish.id
  ).slice(0, 3);

  const handleReserve = () => {
    onReserveWithDish(dish);
    onClose();
  };

  const handleBackToMenu = () => {
    onClose();
    onNavigate('menu');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-[#5d0202] border-2 border-[#F2C14E] rounded-2xl shadow-2xl text-stone-100 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Top Breadcrumbs & Close bar */}
        <div className="bg-[#420101] border-b border-[#F2C14E]/30 px-6 py-3 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 text-xs text-stone-300">
            <button
              onClick={() => {
                onClose();
                onNavigate('home');
              }}
              className="hover:text-[#F2C14E] transition-colors cursor-pointer"
            >
              {t.breadcrumbHome}
            </button>
            <span>/</span>
            <button
              onClick={handleBackToMenu}
              className="hover:text-[#F2C14E] transition-colors cursor-pointer"
            >
              {t.breadcrumbMenu}
            </button>
            <span>/</span>
            <span className="text-[#F2C14E] font-bold truncate max-w-[200px] sm:max-w-xs">
              {dish.name[lang]}
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded text-stone-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            ✕
          </button>
        </div>

        {/* Scrollable Modal Content */}
        <div className="overflow-y-auto p-6 sm:p-8 space-y-8 flex-1">
          {/* Main Dish Presentation: Split Grid */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
            {/* Left: Large Dish Photo */}
            <div className="md:col-span-6 relative rounded-xl overflow-hidden border border-[#F2C14E]/50 shadow-xl bg-stone-900 aspect-4/3 sm:aspect-auto sm:h-80">
              <img
                src={dish.image}
                alt={dish.name[lang]}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              {dish.isSignature && (
                <div className="absolute top-3 left-3 bg-[#F2C14E] text-[#1A1A1A] font-black text-xs px-3 py-1 rounded shadow-lg flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-[#870505]" />
                  <span>SIGNATURE DISH</span>
                </div>
              )}
            </div>

            {/* Right: Info & Primary Actions */}
            <div className="md:col-span-6 flex flex-col justify-between h-full space-y-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-serif font-black text-[#F2C14E] text-gold-radiant leading-tight">
                  {dish.name[lang]}
                </h1>

                {/* Price Display */}
                <div className="mt-3 inline-flex items-baseline gap-1 text-2xl sm:text-3xl font-mono font-bold text-[#F2C14E] bg-[#420101] px-3.5 py-1.5 rounded-lg border border-[#F2C14E]/40">
                  <span>{dish.formattedPrice}</span>
                  <span className="text-sm font-sans text-[#F2C14E]/80">VNĐ</span>
                </div>

                {/* Full Description */}
                <p className="mt-4 text-xs sm:text-sm text-stone-200 leading-relaxed">
                  {dish.fullDescription[lang]}
                </p>
              </div>

              {/* Online Order notice as required in brief */}
              <div className="flex items-center gap-2 p-3 rounded bg-[#400101] border border-[#F2C14E]/30 text-xs text-stone-300">
                <Info className="w-4 h-4 text-[#F2C14E] shrink-0" />
                <span>{t.reservationNote}</span>
              </div>

              {/* Primary Action Buttons */}
              <div className="pt-2 flex flex-col sm:flex-row gap-3">
                {/* [Đặt bàn] - Primary Button */}
                <button
                  onClick={handleReserve}
                  className="flex-1 px-6 py-3.5 bg-[#F2C14E] text-[#1A1A1A] font-bold text-xs sm:text-sm uppercase tracking-wider rounded-lg shadow-xl hover:bg-[#ffe380] transform active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <CalendarCheck className="w-4 h-4 text-[#870505]" />
                  <span>{t.btnReserveThis}</span>
                </button>

                {/* [Quay lại thực đơn] */}
                <button
                  onClick={handleBackToMenu}
                  className="px-5 py-3.5 bg-[#400101] hover:bg-[#870505] border border-stone-500 text-stone-200 font-semibold text-xs sm:text-sm rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>{t.backToMenu}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Ingredients Section */}
          <div className="bg-[#420101] border border-[#F2C14E]/30 rounded-xl p-6">
            <h2 className="text-base sm:text-lg font-serif font-bold text-[#F2C14E] mb-4 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-[#F2C14E]" />
              <span>{t.ingredientsTitle}</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {dish.ingredients[lang].map((ing, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-2 text-xs sm:text-sm text-stone-200 bg-[#5d0202] p-2.5 rounded border border-[#F2C14E]/20"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-[#F2C14E] shrink-0" />
                  <span>{ing}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Related Dishes (Món cùng loại) */}
          {relatedDishes.length > 0 && (
            <div>
              <h2 className="text-base sm:text-lg font-serif font-bold text-[#F2C14E] mb-4">
                {t.relatedTitle}
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {relatedDishes.map((rel) => (
                  <div
                    key={rel.id}
                    onClick={() => onSelectDish(rel)}
                    className="group bg-[#420101] border border-[#F2C14E]/30 hover:border-[#F2C14E] rounded-lg p-3 flex gap-3 cursor-pointer transition-all hover:bg-[#500202]"
                  >
                    <img
                      src={rel.image}
                      alt={rel.name[lang]}
                      className="w-16 h-16 object-cover rounded shrink-0"
                      referrerPolicy="no-referrer"
                    />
                    <div className="flex flex-col justify-between overflow-hidden">
                      <h4 className="text-xs font-serif font-bold text-[#F2C14E] group-hover:underline truncate">
                        {rel.name[lang]}
                      </h4>
                      <span className="text-xs font-mono font-bold text-stone-200">
                        {rel.formattedPrice}đ
                      </span>
                      <span className="text-[10px] text-stone-400">
                        {lang === 'vi' ? 'Xem món →' : 'View dish →'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
