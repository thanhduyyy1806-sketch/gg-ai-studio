import React, { useState } from 'react';
import { Language, PageView, Article } from '../types';
import { ARTICLES } from '../data/news';
import { translations } from '../data/translations';
import { 
  Calendar, 
  Clock, 
  ArrowRight, 
  ArrowLeft, 
  CalendarCheck, 
  Eye, 
  FileText, 
  Image as ImageIcon, 
  ZoomIn, 
  Sparkles,
  BookOpen,
  Share2,
  CheckCircle2
} from 'lucide-react';

interface NewsSectionProps {
  lang: Language;
  onNavigate: (view: PageView) => void;
  onHeadingClick: () => void;
  selectedArticle: Article | null;
  onSelectArticle: (article: Article | null) => void;
}

export const NewsSection: React.FC<NewsSectionProps> = ({
  lang,
  onNavigate,
  onHeadingClick,
  selectedArticle,
  onSelectArticle,
}) => {
  const [currentPage, setCurrentPage] = useState<1 | 2>(1);
  const [viewMode, setViewMode] = useState<'graphic' | 'hybrid'>('graphic');
  const [articleViewMode, setArticleViewMode] = useState<'graphic' | 'text'>('graphic');
  const [isZoomModalOpen, setIsZoomModalOpen] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const t = translations[lang].news;

  // Page 1 has 5 articles, Page 2 has 4 articles (matching user's Canva design)
  const page1Articles = ARTICLES.slice(0, 5);
  const page2Articles = ARTICLES.slice(5, 9);
  const currentArticles = currentPage === 1 ? page1Articles : page2Articles;

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  return (
    <div className="py-8 sm:py-14 bg-[#870505] min-h-screen text-stone-100">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Breadcrumb Navigation */}
        <div className="flex items-center gap-2 text-xs text-stone-300 mb-6 flex-wrap">
          <button
            onClick={() => onNavigate('home')}
            className="hover:text-[#F2C14E] transition-colors cursor-pointer"
          >
            {translations[lang].nav.home}
          </button>
          <span>/</span>
          <button
            onClick={() => onSelectArticle(null)}
            className={`cursor-pointer transition-colors ${!selectedArticle ? 'text-[#F2C14E] font-bold' : 'hover:text-[#F2C14E]'}`}
          >
            {t.pageTitle}
          </button>
          {selectedArticle && (
            <>
              <span>/</span>
              <span className="text-[#F2C14E] font-medium truncate max-w-[240px] sm:max-w-md">
                {selectedArticle.title[lang]}
              </span>
            </>
          )}
        </div>

        {/* ========================================================
            CASE 1: CHI TIẾT BÀI VIẾT (FULL ARTICLE DETAIL VIEW)
            ======================================================== */}
        {selectedArticle ? (
          <article className="bg-[#5d0202] border-2 border-[#F2C14E]/70 rounded-2xl p-5 sm:p-8 lg:p-10 shadow-2xl animate-in fade-in duration-200">
            {/* Top Bar inside Article */}
            <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-[#F2C14E]/25">
              <button
                onClick={() => onSelectArticle(null)}
                className="inline-flex items-center gap-2 text-xs sm:text-sm font-bold text-[#F2C14E] hover:underline cursor-pointer bg-[#870505] px-3.5 py-1.5 rounded-lg border border-[#F2C14E]/40"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>{t.backToList}</span>
              </button>

              {/* View Switcher: Canva Graphic vs Text Mode */}
              <div className="flex items-center gap-1.5 bg-[#400101] p-1 rounded-lg border border-[#F2C14E]/40 text-xs">
                <button
                  onClick={() => setArticleViewMode('graphic')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-semibold transition-all cursor-pointer ${
                    articleViewMode === 'graphic'
                      ? 'bg-[#F2C14E] text-[#1A1A1A] shadow'
                      : 'text-stone-300 hover:text-white'
                  }`}
                >
                  <ImageIcon className="w-3.5 h-3.5" />
                  <span>Bản thiết kế gốc (Canva)</span>
                </button>
                <button
                  onClick={() => setArticleViewMode('text')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-semibold transition-all cursor-pointer ${
                    articleViewMode === 'text'
                      ? 'bg-[#F2C14E] text-[#1A1A1A] shadow'
                      : 'text-stone-300 hover:text-white'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Bản đọc văn bản</span>
                </button>
              </div>
            </div>

            {/* Article Metadata Tags */}
            <div className="mb-4 flex flex-wrap items-center gap-3 text-xs text-stone-300">
              <span className="bg-[#870505] border border-[#F2C14E]/60 px-2.5 py-1 rounded text-[#F2C14E] font-bold">
                {selectedArticle.category[lang]}
              </span>
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-[#F2C14E]" />
                {selectedArticle.date}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-[#F2C14E]" />
                {selectedArticle.readTime}
              </span>
              <span>•</span>
              <span className="text-stone-300 font-medium">Tác giả: {selectedArticle.author}</span>
            </div>

            {/* Headline */}
            <h1
              onClick={onHeadingClick}
              className="text-xl sm:text-3xl lg:text-4xl font-serif font-black text-[#F2C14E] text-gold-radiant mb-6 leading-tight cursor-pointer hover:underline"
              title="Bấm để xem cảnh báo mạo danh & bảo vệ bản quyền"
            >
              {selectedArticle.title[lang]}
            </h1>

            {/* ARTICLE DISPLAY: GRAPHIC DESIGN MODE (DEFAULT) */}
            {articleViewMode === 'graphic' ? (
              <div className="my-6">
                <div className="relative rounded-xl overflow-hidden border-2 border-[#F2C14E]/60 shadow-2xl bg-stone-900 group">
                  {/* Canva Graphic Article Image */}
                  <img
                    src={selectedArticle.id === 'news-1-chinsu-pho-story' 
                      ? '/news/news-article-chinsu.png' 
                      : selectedArticle.image}
                    alt={selectedArticle.title[lang]}
                    className="w-full h-auto object-contain mx-auto max-h-[85vh] transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />

                  {/* Overlay Fullscreen Zoom Button */}
                  <div className="absolute top-4 right-4 flex items-center gap-2">
                    <button
                      onClick={() => setIsZoomModalOpen(true)}
                      className="px-3.5 py-1.5 rounded-lg bg-[#870505]/90 hover:bg-[#870505] text-[#F2C14E] border border-[#F2C14E] text-xs font-bold shadow-lg flex items-center gap-1.5 backdrop-blur-sm cursor-pointer transition-all"
                    >
                      <ZoomIn className="w-4 h-4" />
                      <span>Phóng to toàn màn hình</span>
                    </button>
                  </div>
                </div>

                <div className="mt-4 p-4 rounded-xl bg-[#870505]/60 border border-[#F2C14E]/30 text-xs sm:text-sm text-stone-200 flex items-center justify-between flex-wrap gap-3">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-[#F2C14E]" />
                    <span>Đang hiển thị bản thiết kế bài viết độc quyền từ Phở Thìn Bờ Hồ & Canva.</span>
                  </div>
                  <button
                    onClick={() => setArticleViewMode('text')}
                    className="text-[#F2C14E] hover:underline font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <span>Xem dạng văn bản cuộn đọc</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ) : (
              /* ARTICLE DISPLAY: TEXT READING MODE */
              <div className="my-6">
                <div className="rounded-xl overflow-hidden mb-8 border border-[#F2C14E]/40 max-h-[460px] bg-stone-900">
                  <img
                    src={selectedArticle.id === 'news-1-chinsu-pho-story' 
                      ? '/news/news-article-chinsu.png' 
                      : selectedArticle.image}
                    alt={selectedArticle.title[lang]}
                    className="w-full h-full object-cover object-top"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="space-y-4 text-sm sm:text-base text-stone-200 leading-relaxed font-normal bg-[#870505]/40 p-6 sm:p-8 rounded-xl border border-[#F2C14E]/30">
                  {selectedArticle.content[lang].map((p, idx) => (
                    <p key={idx} className="leading-relaxed">
                      {p}
                    </p>
                  ))}
                </div>
              </div>
            )}

            {/* Related Articles / Footer Actions */}
            <div className="mt-10 pt-6 border-t border-[#F2C14E]/30 flex flex-col sm:flex-row items-center justify-between gap-4">
              <button
                onClick={() => onSelectArticle(null)}
                className="text-xs sm:text-sm font-bold text-stone-300 hover:text-[#F2C14E] flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>{t.backToList}</span>
              </button>

              <div className="flex items-center gap-3">
                <button
                  onClick={handleShare}
                  className="px-4 py-2 bg-[#870505] text-[#F2C14E] border border-[#F2C14E]/50 font-semibold text-xs rounded flex items-center gap-1.5 hover:bg-[#a10606] transition-colors cursor-pointer"
                >
                  {copiedLink ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
                  <span>{copiedLink ? 'Đã sao chép link' : 'Chia sẻ'}</span>
                </button>

                <button
                  onClick={() => onNavigate('reservation')}
                  className="px-6 py-2.5 bg-[#F2C14E] text-[#1A1A1A] font-bold text-xs uppercase tracking-wider rounded flex items-center gap-2 hover:bg-[#ffe380] transition-colors cursor-pointer shadow-lg"
                >
                  <CalendarCheck className="w-4 h-4 text-[#870505]" />
                  <span>{translations[lang].hero.btnReserve}</span>
                </button>
              </div>
            </div>

            {/* Zoom Fullscreen Modal */}
            {isZoomModalOpen && (
              <div 
                className="fixed inset-0 z-50 bg-black/95 flex flex-col items-center justify-center p-4 sm:p-8 animate-in fade-in"
                onClick={() => setIsZoomModalOpen(false)}
              >
                <div className="absolute top-4 right-4 z-10 flex items-center gap-3">
                  <span className="text-xs text-stone-300 bg-black/60 px-3 py-1.5 rounded-lg border border-stone-700">
                    Bấm bất kỳ đâu để đóng
                  </span>
                  <button
                    onClick={() => setIsZoomModalOpen(false)}
                    className="p-2 rounded-full bg-[#870505] text-white hover:bg-red-700 transition-colors"
                  >
                    ✕
                  </button>
                </div>
                <div className="max-w-5xl max-h-[90vh] overflow-auto rounded-lg border-2 border-[#F2C14E]/60 shadow-2xl">
                  <img
                    src={selectedArticle.id === 'news-1-chinsu-pho-story' 
                      ? '/news/news-article-chinsu.png' 
                      : selectedArticle.image}
                    alt={selectedArticle.title[lang]}
                    className="w-full h-auto object-contain"
                  />
                </div>
              </div>
            )}
          </article>
        ) : (
          /* ========================================================
              CASE 2: BẢNG TIN TỔNG QUAN (CANVA DESIGN IMAGE BOARD)
              ======================================================== */
          <div>
            {/* Header Title with warning modal trigger */}
            <div className="text-center max-w-3xl mx-auto mb-8">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-[#5d0202] border border-[#F2C14E]/60 text-[#F2C14E] text-xs font-semibold uppercase tracking-wider mb-3">
                <BookOpen className="w-3.5 h-3.5" />
                <span>Góc Tin Tức & Di Sản Văn Hoá</span>
              </div>
              <h1
                onClick={onHeadingClick}
                className="text-3xl sm:text-5xl font-serif font-black text-[#F2C14E] text-gold-radiant cursor-pointer hover:opacity-95 transition-opacity"
                title="Bấm để xem cảnh báo mạo danh & bảo vệ bản quyền"
              >
                {t.pageTitle}
              </h1>
              <p className="mt-2 text-sm sm:text-base text-stone-200">
                {currentPage === 1 
                  ? 'Cập nhật những hoạt động, hành trình đưa vị phở gia truyền từ ngõ nhỏ 61 Đinh Tiên Hoàng vươn tầm quốc tế'
                  : 'Hoạt động cộng đồng, văn hoá và hành trình gìn giữ phong vị Phở Thìn Bờ Hồ'}
              </p>
            </div>

            {/* Navigation Tabs: Trang 1 (5 bài) vs Trang 2 (4 bài) */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-8 bg-[#5d0202] p-3 sm:p-4 rounded-xl border border-[#F2C14E]/40 shadow-lg">
              {/* Pagination Page Switcher */}
              <div className="flex items-center gap-2 sm:gap-3 w-full sm:w-auto justify-center">
                <button
                  onClick={() => setCurrentPage(1)}
                  className={`flex-1 sm:flex-none px-4 sm:px-6 py-2.5 rounded-lg text-xs sm:text-sm font-bold uppercase tracking-wider transition-all cursor-pointer ${
                    currentPage === 1
                      ? 'bg-[#F2C14E] text-[#1A1A1A] shadow-md scale-102'
                      : 'bg-[#870505] text-stone-200 border border-[#F2C14E]/30 hover:border-[#F2C14E] hover:text-white'
                  }`}
                >
                  <span>Trang 1 • 5 Bài Mới Nhất</span>
                </button>
                <button
                  onClick={() => setCurrentPage(2)}
                  className={`flex-1 sm:flex-none px-4 sm:px-6 py-2.5 rounded-lg text-xs sm:text-sm font-bold uppercase tracking-wider transition-all cursor-pointer ${
                    currentPage === 2
                      ? 'bg-[#F2C14E] text-[#1A1A1A] shadow-md scale-102'
                      : 'bg-[#870505] text-stone-200 border border-[#F2C14E]/30 hover:border-[#F2C14E] hover:text-white'
                  }`}
                >
                  <span>Trang 2 • 4 Bài Cộng Đồng</span>
                </button>
              </div>

              {/* View options: Graphic view vs Interactive card list */}
              <div className="flex items-center gap-2 text-xs">
                <span className="text-stone-300 hidden md:inline">Hiển thị:</span>
                <button
                  onClick={() => setViewMode('graphic')}
                  className={`px-3 py-1.5 rounded-md font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                    viewMode === 'graphic'
                      ? 'bg-[#870505] text-[#F2C14E] border border-[#F2C14E]'
                      : 'text-stone-300 hover:text-white'
                  }`}
                >
                  <ImageIcon className="w-3.5 h-3.5" />
                  <span>Bản thiết kế ảnh</span>
                </button>
                <button
                  onClick={() => setViewMode('hybrid')}
                  className={`px-3 py-1.5 rounded-md font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                    viewMode === 'hybrid'
                      ? 'bg-[#870505] text-[#F2C14E] border border-[#F2C14E]'
                      : 'text-stone-300 hover:text-white'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Ảnh kèm danh sách</span>
                </button>
              </div>
            </div>

            {/* ========================================================
                MAIN VISUAL: THE AUTHENTIC CANVA DESIGN IMAGE BOARD
                ======================================================== */}
            <div className="relative rounded-2xl overflow-hidden border-3 border-[#F2C14E]/80 shadow-[0_15px_45px_rgba(0,0,0,0.6)] bg-stone-950">
              
              {/* Canva Graphic for Current Page */}
              <div className="relative">
                <img
                  src={currentPage === 1 ? '/news/news-page-1.png' : '/news/news-page-2.png'}
                  alt={currentPage === 1 ? 'Bảng tin Phở Thìn Bờ Hồ - Trang 1' : 'Bảng tin Phở Thìn Bờ Hồ - Trang 2'}
                  className="w-full h-auto block select-none"
                  referrerPolicy="no-referrer"
                />

                {/* INTERACTIVE HOTSPOTS FOR PAGE 1 (5 ARTICLES) */}
                {currentPage === 1 && (
                  <>
                    {/* Hotspot 1: Header area -> Triggers map warning */}
                    <div
                      onClick={onHeadingClick}
                      className="absolute top-0 left-0 w-full h-[22%] cursor-pointer group"
                      title="Bấm vào tiêu đề bảng tin để xem cảnh báo mạo danh & bảo vệ thương hiệu"
                    >
                      <div className="absolute top-3 right-4 opacity-0 group-hover:opacity-100 transition-opacity bg-[#870505]/95 border border-[#F2C14E] text-[#F2C14E] text-[11px] font-bold px-3 py-1 rounded-md shadow-lg pointer-events-none">
                        ⚠️ Bấm để xem cảnh báo mạo danh
                      </div>
                    </div>

                    {/* Hotspot 2: Major Featured Hero Card (Chin-su Phở Story) on the left (x: 4% to 50%, y: 22% to 92%) */}
                    <div
                      onClick={() => onSelectArticle(page1Articles[0])}
                      className="absolute top-[22%] left-[4%] w-[46%] h-[70%] rounded-xl cursor-pointer transition-all duration-200 border-2 border-transparent hover:border-[#F2C14E] hover:bg-[#F2C14E]/10 group"
                      title="Bấm để đọc bài viết chi tiết Chin-su Phở Story"
                    >
                      <div className="absolute bottom-4 left-4 right-4 opacity-95 group-hover:opacity-100 transition-all transform group-hover:translate-y-[-2px]">
                        <button className="w-full py-2 px-3 bg-[#870505] hover:bg-[#a30606] text-[#F2C14E] border-2 border-[#F2C14E] text-xs sm:text-sm font-bold uppercase tracking-wider rounded-lg shadow-xl flex items-center justify-center gap-2">
                          <span>Đọc bài viết chi tiết</span>
                          <ArrowRight className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Hotspot 3: Top Right Card (Ngày Việt Nam ở nước ngoài) */}
                    <div
                      onClick={() => onSelectArticle(page1Articles[1])}
                      className="absolute top-[22%] left-[52%] w-[44%] h-[23%] rounded-lg cursor-pointer transition-all duration-200 border-2 border-transparent hover:border-[#F2C14E] hover:bg-[#F2C14E]/10 group"
                      title="Bấm để đọc bài viết"
                    >
                      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-[#870505] text-[#F2C14E] text-[10px] font-bold px-2 py-0.5 rounded border border-[#F2C14E]">
                        Xem bài →
                      </div>
                    </div>

                    {/* Hotspot 4: Middle Right Card (Phở ông Thìn vươn ra thế giới) */}
                    <div
                      onClick={() => onSelectArticle(page1Articles[2])}
                      className="absolute top-[46%] left-[52%] w-[44%] h-[23%] rounded-lg cursor-pointer transition-all duration-200 border-2 border-transparent hover:border-[#F2C14E] hover:bg-[#F2C14E]/10 group"
                      title="Bấm để đọc bài viết"
                    >
                      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-[#870505] text-[#F2C14E] text-[10px] font-bold px-2 py-0.5 rounded border border-[#F2C14E]">
                        Xem bài →
                      </div>
                    </div>

                    {/* Hotspot 5: Bottom Right Card (Hơn 70 năm lưu giữ hương vị) */}
                    <div
                      onClick={() => onSelectArticle(page1Articles[4])}
                      className="absolute top-[70%] left-[52%] w-[44%] h-[23%] rounded-lg cursor-pointer transition-all duration-200 border-2 border-transparent hover:border-[#F2C14E] hover:bg-[#F2C14E]/10 group"
                      title="Bấm để đọc bài viết"
                    >
                      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-[#870505] text-[#F2C14E] text-[10px] font-bold px-2 py-0.5 rounded border border-[#F2C14E]">
                        Xem bài →
                      </div>
                    </div>
                  </>
                )}

                {/* INTERACTIVE HOTSPOTS FOR PAGE 2 (4 ARTICLES) */}
                {currentPage === 2 && (
                  <>
                    {/* Top Heading hotspot -> Triggers warning modal */}
                    <div
                      onClick={onHeadingClick}
                      className="absolute top-0 left-0 w-full h-[22%] cursor-pointer group"
                      title="Bấm vào tiêu đề bảng tin để xem cảnh báo"
                    >
                      <div className="absolute top-3 right-4 opacity-0 group-hover:opacity-100 transition-opacity bg-[#870505]/95 border border-[#F2C14E] text-[#F2C14E] text-[11px] font-bold px-3 py-1 rounded-md shadow-lg pointer-events-none">
                        ⚠️ Bấm để xem cảnh báo mạo danh
                      </div>
                    </div>

                    {/* Card 1: Top Left */}
                    <div
                      onClick={() => onSelectArticle(page2Articles[0])}
                      className="absolute top-[23%] left-[4%] w-[45%] h-[34%] rounded-xl cursor-pointer transition-all duration-200 border-2 border-transparent hover:border-[#F2C14E] hover:bg-[#F2C14E]/10 group"
                      title="Bấm để đọc bài viết"
                    >
                      <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-[#870505] text-[#F2C14E] text-[11px] font-bold px-2.5 py-1 rounded border border-[#F2C14E]">
                        Xem bài chi tiết →
                      </div>
                    </div>

                    {/* Card 2: Top Right */}
                    <div
                      onClick={() => onSelectArticle(page2Articles[1])}
                      className="absolute top-[23%] left-[51%] w-[45%] h-[34%] rounded-xl cursor-pointer transition-all duration-200 border-2 border-transparent hover:border-[#F2C14E] hover:bg-[#F2C14E]/10 group"
                      title="Bấm để đọc bài viết"
                    >
                      <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-[#870505] text-[#F2C14E] text-[11px] font-bold px-2.5 py-1 rounded border border-[#F2C14E]">
                        Xem bài chi tiết →
                      </div>
                    </div>

                    {/* Card 3: Bottom Left */}
                    <div
                      onClick={() => onSelectArticle(page2Articles[2])}
                      className="absolute top-[59%] left-[4%] w-[45%] h-[34%] rounded-xl cursor-pointer transition-all duration-200 border-2 border-transparent hover:border-[#F2C14E] hover:bg-[#F2C14E]/10 group"
                      title="Bấm để đọc bài viết"
                    >
                      <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-[#870505] text-[#F2C14E] text-[11px] font-bold px-2.5 py-1 rounded border border-[#F2C14E]">
                        Xem bài chi tiết →
                      </div>
                    </div>

                    {/* Card 4: Bottom Right */}
                    <div
                      onClick={() => onSelectArticle(page2Articles[3])}
                      className="absolute top-[59%] left-[51%] w-[45%] h-[34%] rounded-xl cursor-pointer transition-all duration-200 border-2 border-transparent hover:border-[#F2C14E] hover:bg-[#F2C14E]/10 group"
                      title="Bấm để đọc bài viết"
                    >
                      <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-[#870505] text-[#F2C14E] text-[11px] font-bold px-2.5 py-1 rounded border border-[#F2C14E]">
                        Xem bài chi tiết →
                      </div>
                    </div>
                  </>
                )}
              </div>

              {/* Bottom bar of Graphic Container */}
              <div className="p-3 bg-[#400101] border-t border-[#F2C14E]/30 flex items-center justify-between flex-wrap gap-2 text-xs text-stone-300">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#F2C14E]" />
                  <span>Mẹo: Bạn có thể bấm trực tiếp vào từng bài trên ảnh để mở bài viết chi tiết!</span>
                </span>
                <span className="text-[#F2C14E] font-medium">
                  {currentPage === 1 ? '5 bài viết hiển thị' : '4 bài viết hiển thị'}
                </span>
              </div>
            </div>

            {/* QUICK-ACCESS ARTICLE CARDS LIST (Shown below the graphic or in hybrid view) */}
            <div className="mt-12">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl sm:text-2xl font-serif font-bold text-[#F2C14E]">
                  {currentPage === 1 ? 'Danh Mục Bài Viết Trang 1 (5 Bài)' : 'Danh Mục Bài Viết Trang 2 (4 Bài)'}
                </h3>
                <span className="text-xs text-stone-300">
                  Bấm vào bài để đọc chi tiết hoặc chuyển chế độ đọc
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {currentArticles.map((article) => (
                  <div
                    key={article.id}
                    onClick={() => onSelectArticle(article)}
                    className="bg-[#5d0202] border border-[#F2C14E]/40 hover:border-[#F2C14E] rounded-xl p-4 sm:p-5 flex flex-col justify-between transition-all duration-200 hover:-translate-y-1 hover:shadow-xl cursor-pointer group"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2 text-[11px] text-stone-300 mb-2.5">
                        <span className="bg-[#870505] text-[#F2C14E] px-2 py-0.5 rounded font-bold border border-[#F2C14E]/30">
                          {article.category[lang]}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3 text-[#F2C14E]" />
                          {article.date}
                        </span>
                      </div>

                      <h4 className="text-sm sm:text-base font-serif font-bold text-[#F2C14E] group-hover:text-[#ffe48a] leading-snug line-clamp-2 mb-2">
                        {article.title[lang]}
                      </h4>

                      <p className="text-xs text-stone-300 line-clamp-3 leading-relaxed mb-4">
                        {article.excerpt[lang]}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-[#F2C14E]/20 flex items-center justify-between text-xs text-[#F2C14E] font-bold">
                      <span className="group-hover:underline">Đọc bài viết chi tiết</span>
                      <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Bottom Pagination Buttons */}
            <div className="mt-10 flex items-center justify-center gap-3">
              <button
                onClick={() => setCurrentPage(1)}
                className={`px-5 py-2.5 rounded-lg text-xs sm:text-sm font-bold uppercase tracking-wider transition-all cursor-pointer ${
                  currentPage === 1
                    ? 'bg-[#F2C14E] text-[#1A1A1A] shadow-lg'
                    : 'bg-[#5d0202] text-stone-300 border border-[#F2C14E]/40 hover:text-white'
                }`}
              >
                ← Trang 1 (5 Bài)
              </button>
              <button
                onClick={() => setCurrentPage(2)}
                className={`px-5 py-2.5 rounded-lg text-xs sm:text-sm font-bold uppercase tracking-wider transition-all cursor-pointer ${
                  currentPage === 2
                    ? 'bg-[#F2C14E] text-[#1A1A1A] shadow-lg'
                    : 'bg-[#5d0202] text-stone-300 border border-[#F2C14E]/40 hover:text-white'
                }`}
              >
                Trang 2 (4 Bài) →
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
