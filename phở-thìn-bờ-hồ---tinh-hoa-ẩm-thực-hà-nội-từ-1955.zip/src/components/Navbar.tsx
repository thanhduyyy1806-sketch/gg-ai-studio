import React, { useState } from 'react';
import { Language, PageView } from '../types';
import { translations } from '../data/translations';
import { Menu as MenuIcon, X, Globe, AlertCircle, UtensilsCrossed } from 'lucide-react';

interface NavbarProps {
  currentView: PageView;
  onNavigate: (view: PageView) => void;
  lang: Language;
  onLanguageChange: (lang: Language) => void;
  onTriggerWarning: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  lang,
  onLanguageChange,
  onTriggerWarning,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);
  const t = translations[lang].nav;

  const navItems: { view: PageView; label: string }[] = [
    { view: 'home', label: t.home },
    { view: 'about', label: t.about },
    { view: 'menu', label: t.menu },
    { view: 'news', label: t.news },
    { view: 'partners', label: t.partners },
    { view: 'contact', label: t.contact },
  ];

  const languages: { code: Language; label: string; flag: string }[] = [
    { code: 'vi', label: 'Tiếng Việt', flag: '🇻🇳' },
    { code: 'en', label: 'English', flag: '🇬🇧' },
    { code: 'zh', label: '中文', flag: '🇨🇳' },
    { code: 'ko', label: '한국어', flag: '🇰🇷' },
  ];

  const currentLangObj = languages.find((l) => l.code === lang) || languages[0];

  const handleNavClick = (view: PageView) => {
    onNavigate(view);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#870505]/95 backdrop-blur-md border-b border-[#F2C14E]/30 shadow-md">
      {/* Top micro alert ticker */}
      <div className="bg-[#5d0202] text-stone-200 text-[11px] py-1 px-4 border-b border-[#F2C14E]/20">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <button
            onClick={onTriggerWarning}
            className="flex items-center gap-1.5 text-[#F2C14E] hover:underline cursor-pointer transition-colors"
          >
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">
              {lang === 'vi'
                ? 'Lưu ý: Chỉ có 4 cơ sở chính thức tại Hà Nội • Cảnh báo địa điểm giả mạo'
                : 'Advisory: Only 4 verified branches in Hanoi • Beware of copycat map pins'}
            </span>
          </button>
          <span className="hidden md:inline text-stone-300">
            {lang === 'vi' ? 'Giờ mở cửa: Sáng 06:00–13:00 | Chiều 17:00–22:00' : 'Open: 06:00–13:00 & 17:00–22:00'}
          </span>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
        {/* Zone 1: Brand Wordmark / Logo */}
        <button
          onClick={() => handleNavClick('home')}
          className="flex items-center gap-3 text-left group cursor-pointer focus:outline-none"
        >
          {/* Logo seal */}
          <div className="w-11 h-11 rounded-full bg-[#F2C14E] border-2 border-[#1A1A1A] p-0.5 flex items-center justify-center shrink-0 shadow-sm transition-transform group-hover:scale-105">
            <div className="w-full h-full rounded-full border border-[#870505] flex flex-col items-center justify-center bg-[#870505] text-[#F2C14E]">
              <UtensilsCrossed className="w-4 h-4 text-[#F2C14E]" />
              <span className="text-[8px] font-bold tracking-tight">1955</span>
            </div>
          </div>

          <div className="flex flex-col">
            <span className="text-lg sm:text-xl font-serif font-extrabold text-[#F2C14E] tracking-tight group-hover:text-[#ffe48a] transition-colors leading-none">
              PHỞ THÌN BỜ HỒ
            </span>
            <span className="text-[10px] uppercase tracking-wider text-stone-300 font-medium mt-0.5">
              Hà Nội Từ 1955 • 4 Cơ Sở
            </span>
          </div>
        </button>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
          {navItems.map((item) => {
            const isActive = currentView === item.view;
            return (
              <button
                key={item.view}
                onClick={() => handleNavClick(item.view)}
                className={`px-3 py-1.5 text-xs xl:text-sm font-semibold rounded transition-colors whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'text-[#1A1A1A] bg-[#F2C14E] shadow-sm'
                    : 'text-stone-100 hover:text-[#F2C14E] hover:bg-white/5'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Language Selector & Booking CTA */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Language Selector Dropdown */}
          <div className="relative">
            <button
              onClick={() => setLangDropdownOpen(!langDropdownOpen)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold bg-[#5d0202] text-[#F2C14E] border border-[#F2C14E]/40 rounded hover:border-[#F2C14E] transition-colors cursor-pointer"
              aria-label="Select Language"
            >
              <Globe className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{currentLangObj.flag} {currentLangObj.label}</span>
              <span className="sm:hidden">{currentLangObj.code.toUpperCase()}</span>
            </button>

            {langDropdownOpen && (
              <div className="absolute right-0 mt-2 w-36 bg-[#5d0202] border border-[#F2C14E] rounded shadow-xl py-1 z-50 animate-in fade-in zoom-in-95 duration-150">
                {languages.map((l) => (
                  <button
                    key={l.code}
                    onClick={() => {
                      onLanguageChange(l.code);
                      setLangDropdownOpen(false);
                    }}
                    className={`w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-left cursor-pointer transition-colors ${
                      lang === l.code
                        ? 'bg-[#F2C14E] text-[#1A1A1A] font-bold'
                        : 'text-stone-200 hover:bg-[#870505] hover:text-[#F2C14E]'
                    }`}
                  >
                    <span>{l.flag}</span>
                    <span>{l.label}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Primary Action Button: [Đặt bàn] - Gold bg, Black text */}
          <button
            onClick={() => handleNavClick('reservation')}
            className="px-4 sm:px-5 py-2 text-xs sm:text-sm font-bold bg-[#F2C14E] text-[#1A1A1A] hover:bg-[#ffe382] rounded shadow-md hover:shadow-lg transition-all transform active:scale-95 whitespace-nowrap cursor-pointer"
          >
            {t.reserve}
          </button>

          {/* Mobile hamburger button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-stone-200 hover:text-[#F2C14E] rounded focus:outline-none cursor-pointer"
            aria-label="Toggle Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#5d0202] border-b border-[#F2C14E] px-4 pt-3 pb-6 space-y-2 animate-in slide-in-from-top-3 duration-200">
          {navItems.map((item) => (
            <button
              key={item.view}
              onClick={() => handleNavClick(item.view)}
              className={`w-full text-left px-4 py-2.5 rounded text-sm font-medium transition-colors cursor-pointer ${
                currentView === item.view
                  ? 'bg-[#F2C14E] text-[#1A1A1A] font-bold'
                  : 'text-stone-200 hover:bg-[#870505] hover:text-[#F2C14E]'
              }`}
            >
              {item.label}
            </button>
          ))}
          <div className="pt-2 border-t border-stone-700/60 flex items-center justify-between text-xs text-stone-300">
            <span>Ngôn ngữ:</span>
            <div className="flex gap-2">
              {languages.map((l) => (
                <button
                  key={l.code}
                  onClick={() => onLanguageChange(l.code)}
                  className={`px-2 py-1 rounded text-xs cursor-pointer ${
                    lang === l.code ? 'bg-[#F2C14E] text-[#1A1A1A] font-bold' : 'text-stone-300 hover:text-white'
                  }`}
                >
                  {l.code.toUpperCase()}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
