import React from 'react';
import { Language, PageView } from '../types';
import { translations } from '../data/translations';
import { CalendarCheck, BookOpen, Quote, ShieldAlert, Award } from 'lucide-react';

interface AboutNewspaperProps {
  lang: Language;
  onNavigate: (view: PageView) => void;
  onHeadingClick: () => void;
}

export const AboutNewspaper: React.FC<AboutNewspaperProps> = ({
  lang,
  onNavigate,
  onHeadingClick,
}) => {
  const t = translations[lang].about;

  return (
    <div className="py-12 sm:py-16 bg-[#870505] min-h-screen">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Navigation Breadcrumbs */}
        <div className="flex items-center gap-2 text-xs text-stone-300 mb-6">
          <button
            onClick={() => onNavigate('home')}
            className="hover:text-[#F2C14E] transition-colors cursor-pointer"
          >
            {translations[lang].nav.home}
          </button>
          <span>/</span>
          <span className="text-[#F2C14E] font-medium">{translations[lang].nav.about}</span>
        </div>

        {/* Vintage Broadsheet Newspaper Container (Paper #F3E3B3, Red Oxblood #870505 & Ink Black #1A1A1A) */}
        <article className="newspaper-paper border-4 border-[#1A1A1A] p-6 sm:p-10 lg:p-14 shadow-2xl relative text-[#1A1A1A]">
          {/* Top Newspaper Header / Masthead */}
          <div className="border-b-4 border-double border-[#1A1A1A] pb-6 text-center">
            {/* Top Micro-Header */}
            <div className="flex flex-col sm:flex-row items-center justify-between text-[11px] font-serif font-bold uppercase tracking-widest text-[#870505] border-b border-[#1A1A1A]/30 pb-2 mb-4">
              <span>HÀ NỘI BỜ HỒ • NĂM THỨ 71</span>
              <span>{t.issueDate}</span>
              <span>GIÁ TRỊ DI SẢN: VÔ GIÁ</span>
            </div>

            {/* Masthead Banner Title */}
            <h1
              onClick={onHeadingClick}
              className="newspaper-headline text-3xl sm:text-5xl lg:text-6xl font-black text-[#870505] tracking-tight uppercase cursor-pointer hover:opacity-90 transition-opacity"
              title="Bấm vào tiêu đề để xem cảnh báo giả mạo bản đồ"
            >
              {t.newspaperName}
            </h1>

            <p className="text-xs sm:text-sm font-serif italic text-stone-800 mt-2">
              Cơ quan gìn giữ và lan tỏa tinh hoa phở truyền thống Tràng An từ năm 1955
            </p>

            <div className="mt-4 pt-3 border-t-2 border-[#1A1A1A] flex flex-col md:flex-row items-center justify-between gap-2 text-xs font-mono text-stone-700">
              <span>★ SÁNG LẬP: CỤ BÙI CHÍ THÌN (1955)</span>
              <span>★ ĐỊA CHỈ GỐC: 61 ĐINH TIÊN HOÀNG</span>
              <span>★ 4 CƠ SỞ CHÍNH THỨC</span>
            </div>
          </div>

          {/* Main Headline */}
          <div className="py-8 border-b-2 border-[#1A1A1A] text-center max-w-3xl mx-auto">
            <h2
              onClick={onHeadingClick}
              className="text-2xl sm:text-3xl lg:text-4xl font-serif font-black text-[#870505] leading-tight cursor-pointer hover:opacity-95"
              title="Bấm để xem cảnh báo"
            >
              {t.mainHeadline}
            </h2>
            <p className="mt-3 text-sm sm:text-base font-serif italic text-[#1A1A1A]/85">
              {t.subHeadline}
            </p>
          </div>

          {/* Featured Editorial Photo & Wax Seal */}
          <div className="my-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center border-b-2 border-[#1A1A1A] pb-8">
            <div className="lg:col-span-7 relative">
              <div className="border-2 border-[#1A1A1A] p-2 bg-[#F3E3B3]">
                <img
                  src="/src/assets/images/vintage_hanoi_pho_stall_1790702834461.jpg"
                  alt="Ảnh tư liệu phố cổ Hà Nội và gánh phở cụ Thìn 1955"
                  className="w-full h-auto filter sepia-[0.3] contrast-105"
                  referrerPolicy="no-referrer"
                />
                <p className="text-[11px] font-serif italic text-stone-800 mt-1.5 text-center">
                  Góc phố Đinh Tiên Hoàng bên bờ hồ Hoàn Kiếm – Nơi cụ Bùi Chí Thìn đặt gánh phở đầu tiên năm 1955.
                </p>
              </div>
            </div>

            <div className="lg:col-span-5 flex flex-col justify-center space-y-4">
              {/* Vintage Red Stamp Seal */}
              <div className="border-2 border-dashed border-[#870505] p-4 bg-[#870505]/10 rounded-sm text-center">
                <Award className="w-8 h-8 text-[#870505] mx-auto mb-1" />
                <span className="block text-xs font-mono font-bold text-[#870505] tracking-widest uppercase">
                  {t.sealText}
                </span>
                <p className="text-[11px] text-stone-800 mt-1">
                  Được truyền dạy trực tiếp qua ba đời gia tộc cụ Thìn, bảo lưu công thức ninh xương ống bò thanh trong không mì chính.
                </p>
              </div>

              {/* Literary Pullquote */}
              <div className="bg-[#e9d69e] border-l-4 border-[#870505] p-4 italic font-serif text-sm text-[#1A1A1A] leading-relaxed relative">
                <Quote className="w-5 h-5 text-[#870505]/40 absolute top-2 right-2" />
                {t.quote}
                <span className="block text-xs font-sans not-italic font-bold text-[#870505] mt-2">
                  — Lời bình của thực khách sành ăn Hà Thành xưa
                </span>
              </div>
            </div>
          </div>

          {/* 4 Core Chapters (4 Mục theo yêu cầu trong đề bài) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10 pt-4">
            {/* Mục 1: Giới thiệu Phở Thìn */}
            <div className="space-y-3 pr-0 md:pr-4 border-b md:border-b-0 border-[#1A1A1A]/20 pb-6 md:pb-0">
              <h3
                onClick={onHeadingClick}
                className="text-xl font-serif font-black text-[#870505] border-b-2 border-[#870505] pb-1 cursor-pointer hover:underline"
              >
                {t.sec1Title}
              </h3>
              <p className="text-sm font-serif text-[#1A1A1A] leading-relaxed text-justify first-letter:text-4xl first-letter:font-black first-letter:float-left first-letter:mr-2 first-letter:text-[#870505]">
                Trong muôn vàn thức quà của Hà Nội, phở luôn chiếm giữ vị trí độc tôn. Và giữa lòng ba mươi sáu phố phường, nhắc tới phở bò truyền thống thanh tao, không ai là không nhớ tới Phở Thìn Bờ Hồ. Đây không đơn thuần là một quán ăn, mà là chứng nhân lịch sử, là nếp sinh hoạt văn hoá tao nhã gắn liền với bao thế hệ người Hà Nội gốc.
              </p>
              <p className="text-sm font-serif text-[#1A1A1A] leading-relaxed text-justify">
                Khác biệt lớn nhất của Phở Thìn Bờ Hồ chính là triết lý ẩm thực: giữ trọn sự tinh tế nguyên bản, tôn vinh độ ngọt lành thuần khiết của thịt bò tươi và xương ống ninh nhừ, không lạm dụng gia vị nhân tạo hay dầu mỡ ngấy ngán.
              </p>
            </div>

            {/* Mục 2: Lịch sử hình thành năm 1955 */}
            <div className="space-y-3 pl-0 md:pl-4 border-b md:border-b-0 border-[#1A1A1A]/20 pb-6 md:pb-0">
              <h3
                onClick={onHeadingClick}
                className="text-xl font-serif font-black text-[#870505] border-b-2 border-[#870505] pb-1 cursor-pointer hover:underline"
              >
                {t.sec2Title}
              </h3>
              <p className="text-sm font-serif text-[#1A1A1A] leading-relaxed text-justify first-letter:text-4xl first-letter:font-black first-letter:float-left first-letter:mr-2 first-letter:text-[#870505]">
                Năm 1955, Thủ Đô bước vào những ngày đầu tiên của thời kỳ hòa bình sau giải phóng. Giữa nhịp sống đổi thay rộn rã, chàng trai làng trẻ tuổi Bùi Chí Thìn đã quẩy đôi quang gánh phở đầu tiên ra góc phố Đinh Tiên Hoàng, đối diện Tháp Rùa và Đền Ngọc Sơn.
              </p>
              <p className="text-sm font-serif text-[#1A1A1A] leading-relaxed text-justify">
                Gánh phở của cụ Thìn nhanh chóng nức tiếng khắp phố phường bởi hương thơm nồng ấm và vị thanh ngọt khác lạ. Dù qua thời kỳ bao cấp khó khăn phân phối tem phiếu, gánh phở vẫn bền bỉ đỏ lửa, phục vụ từ các bậc văn nghệ sĩ, trí thức cho đến bà con lao động phố cổ.
              </p>
            </div>

            {/* Mục 3: Xuất thân Phở Thìn */}
            <div className="space-y-3 pr-0 md:pr-4 pt-4 border-b md:border-b-0 border-[#1A1A1A]/20 pb-6 md:pb-0">
              <h3
                onClick={onHeadingClick}
                className="text-xl font-serif font-black text-[#870505] border-b-2 border-[#870505] pb-1 cursor-pointer hover:underline"
              >
                {t.sec3Title}
              </h3>
              <p className="text-sm font-serif text-[#1A1A1A] leading-relaxed text-justify first-letter:text-4xl first-letter:font-black first-letter:float-left first-letter:mr-2 first-letter:text-[#870505]">
                Cụ Bùi Chí Thìn sinh ra tại vùng quê giàu truyền thống hiếu học và trọng nghĩa tình. Với đôi bàn tay tài hoa và cái tâm của người làm nghề, cụ luôn tâm niệm: "Nấu bát phở cho người ăn cũng như nấu cho chính cha mẹ, con cái mình ăn".
              </p>
              <p className="text-sm font-serif text-[#1A1A1A] leading-relaxed text-justify">
                Bí quyết gia truyền của cụ được truyền lại nghiêm ngặt qua 3 đời: từ tỷ lệ nước, thời gian ủ than, cách hớt bọt cho đến kỹ thuật dùng dao bản đập dập miếng thịt thăn bò trên thớt gỗ nghiến. Nhờ sự khắt khe đó, hương vị năm 1955 vẫn vẹn nguyên tới tận hôm nay.
              </p>
            </div>

            {/* Mục 4: Tinh hoa Phở Hà Nội */}
            <div className="space-y-3 pl-0 md:pl-4 pt-4">
              <h3
                onClick={onHeadingClick}
                className="text-xl font-serif font-black text-[#870505] border-b-2 border-[#870505] pb-1 cursor-pointer hover:underline"
              >
                {t.sec4Title}
              </h3>
              <p className="text-sm font-serif text-[#1A1A1A] leading-relaxed text-justify first-letter:text-4xl first-letter:font-black first-letter:float-left first-letter:mr-2 first-letter:text-[#870505]">
                Bát phở Bờ Hồ tinh túy là sự tổng hòa màu sắc và phong vị: bánh phở mỏng dai trắng ngần, thịt bò thái lát hồng tươi mềm ngọt, nước dùng trong vắt ánh vàng hổ phách, điểm xuyết một thảm hành hoa và ngò gai tươi ngát thơm.
              </p>
              <p className="text-sm font-serif text-[#1A1A1A] leading-relaxed text-justify">
                Thêm một chút giấm ớt tỏi ủ chum sành, vài giọt chanh cốm tươi mọng nước và một đĩa quẩy giòn vàng ruộm, thực khách sẽ được tận hưởng trọn vẹn phong vị thanh nhã bậc nhất của ẩm thực Thăng Long – Hà Nội.
              </p>
            </div>
          </div>

          {/* Bottom Newspaper Footer Callouts */}
          <div className="mt-12 pt-6 border-t-4 border-double border-[#1A1A1A] flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-xs font-mono text-stone-800">
              <ShieldAlert className="w-4 h-4 text-[#870505]" />
              <span>LƯU Ý: HỆ THỐNG GỒM 4 CƠ SỞ CHÍNH THỨC TẠI HÀ NỘI</span>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => onNavigate('menu')}
                className="px-4 py-2 border-2 border-[#870505] text-[#870505] font-bold text-xs uppercase tracking-wider rounded hover:bg-[#870505] hover:text-[#F2C14E] transition-colors cursor-pointer"
              >
                {translations[lang].homeCards.discoverMore.replace('→', '').trim()} (Xem Thực Đơn)
              </button>

              <button
                onClick={() => onNavigate('reservation')}
                className="px-5 py-2 bg-[#870505] text-[#F2C14E] font-bold text-xs uppercase tracking-wider rounded hover:bg-[#5d0202] transition-colors flex items-center gap-1.5 cursor-pointer shadow-md"
              >
                <CalendarCheck className="w-3.5 h-3.5" />
                <span>{translations[lang].hero.btnReserve}</span>
              </button>
            </div>
          </div>
        </article>
      </div>
    </div>
  );
};
