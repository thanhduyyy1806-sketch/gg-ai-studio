import React from 'react';
import { Language, PageView } from '../types';
import { translations } from '../data/translations';
import { BRANCHES } from '../data/branches';
import { AlertTriangle, X, MapPin, Phone, ShieldCheck } from 'lucide-react';

interface FakeMapWarningModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onNavigate: (view: PageView) => void;
}

export const FakeMapWarningModal: React.FC<FakeMapWarningModalProps> = ({
  isOpen,
  onClose,
  lang,
  onNavigate,
}) => {
  if (!isOpen) return null;

  const t = translations[lang].warningModal;

  const handleGoToBranches = () => {
    onClose();
    onNavigate('contact');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl bg-[#5d0202] border-2 border-[#F2C14E] rounded-lg shadow-2xl text-stone-100 overflow-hidden"
        role="dialog"
        aria-modal="true"
      >
        {/* Top gold bar */}
        <div className="bg-[#F2C14E] text-[#1A1A1A] px-6 py-2.5 flex items-center justify-between">
          <div className="flex items-center gap-2 font-bold text-xs uppercase tracking-wider">
            <AlertTriangle className="w-4 h-4 text-[#870505]" />
            <span>{t.badge}</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-black/10 transition-colors cursor-pointer text-[#1A1A1A]"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content body */}
        <div className="p-6 max-h-[80vh] overflow-y-auto">
          <div className="flex items-start gap-3 mb-4">
            <div className="p-2.5 rounded-full bg-[#870505] border border-[#F2C14E] shrink-0 text-[#F2C14E]">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl sm:text-2xl font-serif font-bold text-[#F2C14E] leading-snug">
                {t.title}
              </h3>
              <p className="text-xs text-stone-300 mt-1">
                {lang === 'vi' ? 'Thông báo chính thức bảo vệ quyền lợi thực khách của Gia tộc Phở Thìn (1955)' : 'Official Notice by the 1955 Pho Thin Bo Ho Family Heritage'}
              </p>
            </div>
          </div>

          <div className="bg-[#420101] border-l-4 border-[#F2C14E] p-4 mb-4 text-xs sm:text-sm text-stone-200 space-y-2">
            <p className="leading-relaxed">{t.intro}</p>
            <p className="leading-relaxed font-semibold text-[#F2C14E]">
              • {t.rule1}
            </p>
            <p className="leading-relaxed font-semibold text-[#F2C14E]">
              • {t.rule2}
            </p>
          </div>

          {/* 4 Official Verified Branches List */}
          <div className="mt-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#F2C14E] mb-3 flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              <span>
                {lang === 'vi' ? 'DANH SÁCH 4 CƠ SỞ CHÍNH THỨC TẠI HÀ NỘI:' : 'VERIFIED 4 OFFICIAL HANOI LOCATIONS:'}
              </span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {BRANCHES.map((b) => (
                <div
                  key={b.id}
                  className={`p-3 rounded border ${
                    b.isOriginal 
                      ? 'border-[#F2C14E] bg-[#6e0404]' 
                      : 'border-stone-700 bg-[#4d0202]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-[#F2C14E]">
                      {b.code}: {b.name[lang]}
                    </span>
                    {b.isOriginal && (
                      <span className="text-[10px] bg-[#F2C14E] text-[#1A1A1A] font-bold px-1.5 py-0.5 rounded">
                        GỐC 1955
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-stone-200 line-clamp-2">
                    {b.address}
                  </p>
                  <div className="flex items-center gap-1.5 text-xs text-[#F2C14E] font-medium mt-2">
                    <Phone className="w-3.5 h-3.5" />
                    <a href={`tel:${b.phone.replace(/[^0-9+]/g, '')}`} className="hover:underline">
                      {b.phone}
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Action buttons */}
          <div className="mt-6 pt-4 border-t border-stone-700/60 flex flex-col sm:flex-row items-center justify-end gap-3">
            <button
              onClick={handleGoToBranches}
              className="w-full sm:w-auto px-5 py-2.5 bg-[#F2C14E] text-[#1A1A1A] font-bold text-xs uppercase tracking-wider rounded hover:bg-[#ffe380] transition-colors cursor-pointer"
            >
              {t.understood}
            </button>
            <button
              onClick={onClose}
              className="w-full sm:w-auto px-4 py-2.5 border border-stone-400 text-stone-300 font-medium text-xs rounded hover:bg-white/10 transition-colors cursor-pointer"
            >
              {t.close}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
