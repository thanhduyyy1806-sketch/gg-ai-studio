import React, { useState } from 'react';
import { Language, Dish, PageView } from '../types';
import { DISHES } from '../data/dishes';
import { translations } from '../data/translations';
import { Award, ArrowRight, Sparkles } from 'lucide-react';

interface MenuSectionProps {
  lang: Language;
  onNavigate: (view: PageView) => void;
  onSelectDish: (dish: Dish) => void;
  onHeadingClick: () => void;
}

export const MenuSection: React.FC<MenuSectionProps> = ({
  lang,
  onNavigate,
  onSelectDish,
  onHeadingClick,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'pho' | 'drinks' | 'others'>('all');
  const t = translations[lang].menu;

  const phoDishes = DISHES.filter((d) => d.category === 'pho');
  const drinkDishes = DISHES.filter((d) => d.category === 'drinks');
  const otherDishes = DISHES.filter((d) => d.category === 'others');

  const categories = [
    { key: 'all', label: t.tabAll, count: DISHES.length },
    { key: 'pho', label: t.tabPho, count: phoDishes.length },
    { key: 'drinks', label: t.tabDrinks, count: drinkDishes.length },
    { key: 'others', label: t.tabOthers, count: otherDishes.length },
  ] as const;

  return (
    <div className="py-10 sm:py-16 bg-[#870505] min-h-screen text-stone-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb: Trang chủ / Thực đơn */}
        <div className="flex items-center gap-2 text-xs text-stone-300 mb-6">
          <button
            onClick={() => onNavigate('home')}
            className="hover:text-[#F2C14E] transition-colors cursor-pointer"
          >
            {t.breadcrumbHome}
          </button>
          <span>/</span>
          <span className="text-[#F2C14E] font-semibold">{t.breadcrumbMenu}</span>
        </div>

        {/* Big Banner "Thực Đơn" */}
        <div className="relative rounded-2xl overflow-hidden bg-gradient-to-r from-[#5d0202] via-[#870505] to-[#5d0202] border-2 border-[#F2C14E]/50 p-8 sm:p-12 mb-12 shadow-2xl text-center">
          <div className="relative z-10 max-w-2xl mx-auto">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-[#870505] border border-[#F2C14E]/60 text-[#F2C14E] text-xs font-semibold uppercase tracking-wider mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Gia Truyền Từ 1955</span>
            </span>
            <h1
              onClick={onHeadingClick}
              className="text-3xl sm:text-5xl font-serif font-black text-[#F2C14E] text-gold-radiant cursor-pointer hover:opacity-95 transition-opacity"
              title="Bấm vào tiêu đề để xem cảnh báo"
            >
              {t.bannerTitle}
            </h1>
            <p className="mt-3 text-sm sm:text-base text-stone-200">
              {t.bannerSub}
            </p>
          </div>
          {/* Watermark in background */}
          <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#F2C14E_1px,transparent_1px)] [background-size:20px_20px]" />
        </div>

        {/* Category Filter Tabs (Interactive segmented buttons allowed by frontend-design guidelines) */}
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mb-12">
          {categories.map((c) => {
            const isActive = selectedCategory === c.key;
            return (
              <button
                key={c.key}
                onClick={() => setSelectedCategory(c.key)}
                className={`px-4 sm:px-6 py-2.5 rounded-lg text-xs sm:text-sm font-bold uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-[#F2C14E] text-[#1A1A1A] shadow-lg scale-105'
                    : 'bg-[#5d0202] text-stone-300 hover:text-white hover:bg-[#700303] border border-[#F2C14E]/30'
                }`}
              >
                {c.label} ({c.count})
              </button>
            );
          })}
        </div>

        {/* 3 Sequential Groups: Phở -> Đồ uống -> Khác */}
        <div className="space-y-16">
          {/* GROUP 1: PHỞ TRUYỀN THỐNG */}
          {(selectedCategory === 'all' || selectedCategory === 'pho') && (
            <section id="section-pho" className="scroll-mt-24">
              <div className="border-b border-[#F2C14E]/40 pb-3 mb-8 flex items-baseline justify-between">
                <h2
                  onClick={onHeadingClick}
                  className="text-2xl sm:text-3xl font-serif font-bold text-[#F2C14E] text-gold-radiant cursor-pointer hover:underline"
                  title="Bấm để xem cảnh báo"
                >
                  {t.tabPho}
                </h2>
                <span className="text-xs text-stone-300">
                  {phoDishes.length} {lang === 'vi' ? 'món phở' : 'dishes'}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {phoDishes.map((dish) => (
                  <div
                    key={dish.id}
                    onClick={() => onSelectDish(dish)}
                    className="group bg-[#5d0202] border border-[#F2C14E]/30 hover:border-[#F2C14E] rounded-xl overflow-hidden cursor-pointer flex flex-col justify-between transition-all duration-300 hover:-translate-y-1.5 hover:shadow-2xl"
                  >
                    <div>
                      {/* Dish Photo */}
                      <div className="relative aspect-16/10 overflow-hidden bg-stone-900">
                        <img
                          src={dish.image}
                          alt={dish.name[lang]}
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-70" />

                        {/* SIGNATURE badge strictly for Phở tái chín */}
                        {dish.isSignature && (
                          <div className="absolute top-3 left-3 bg-[#F2C14E] text-[#1A1A1A] font-black text-[11px] px-2.5 py-1 rounded shadow-lg flex items-center gap-1">
                            <Award className="w-3.5 h-3.5 text-[#870505]" />
                            <span>{t.signatureBadge}</span>
                          </div>
                        )}

                        <div className="absolute bottom-2.5 right-3 px-2.5 py-1 rounded bg-black/85 border border-[#F2C14E]/50 text-sm font-mono font-bold text-[#F2C14E]">
                          {dish.formattedPrice} {t.vnd}
                        </div>
                      </div>

                      {/* Content */}
                      <div className="p-5">
                        <h3 className="text-lg font-serif font-bold text-[#F2C14E] group-hover:text-[#ffe285] transition-colors leading-snug">
                          {dish.name[lang]}
                        </h3>
                        <p className="mt-2 text-xs sm:text-sm text-stone-200 line-clamp-3 leading-relaxed">
                          {dish.shortDescription[lang]}
                        </p>
                      </div>
                    </div>

                    <div className="p-5 pt-0">
                      <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs text-[#F2C14E] font-semibold">
                        <span>{t.viewDetail}</span>
                        <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* GROUP 2: ĐỒ UỐNG HÀ NỘI */}
          {(selectedCategory === 'all' || selectedCategory === 'drinks') && (
            <section id="section-drinks" className="scroll-mt-24">
              <div className="border-b border-[#F2C14E]/40 pb-3 mb-8 flex items-baseline justify-between">
                <h2
                  onClick={onHeadingClick}
                  className="text-2xl sm:text-3xl font-serif font-bold text-[#F2C14E] text-gold-radiant cursor-pointer hover:underline"
                  title="Bấm để xem cảnh báo"
                >
                  {t.tabDrinks}
                </h2>
                <span className="text-xs text-stone-300">
                  {drinkDishes.length} {lang === 'vi' ? 'đồ uống' : 'drinks'}
                </span>
              </div>

              {/* Compact cards for auxiliary items as specified in design requirements */}
              <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-4">
                {drinkDishes.map((dish) => (
                  <div
                    key={dish.id}
                    onClick={() => onSelectDish(dish)}
                    className="group bg-[#5d0202] border border-[#F2C14E]/30 hover:border-[#F2C14E] rounded-lg overflow-hidden cursor-pointer flex flex-col justify-between transition-all duration-200 hover:-translate-y-1 hover:shadow-lg"
                  >
                    <div className="relative aspect-square overflow-hidden bg-stone-900">
                      <img
                        src={dish.image}
                        alt={dish.name[lang]}
                        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-black/80 text-xs font-mono font-bold text-[#F2C14E]">
                        {dish.formattedPrice} {t.vnd}
                      </div>
                    </div>

                    <div className="p-3">
                      <h3 className="text-xs sm:text-sm font-serif font-bold text-[#F2C14E] line-clamp-1 group-hover:underline">
                        {dish.name[lang]}
                      </h3>
                      <p className="mt-1 text-[11px] text-stone-300 line-clamp-2">
                        {dish.shortDescription[lang]}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* GROUP 3: MÓN ĂN KÈM & KHÁC */}
          {(selectedCategory === 'all' || selectedCategory === 'others') && (
            <section id="section-others" className="scroll-mt-24">
              <div className="border-b border-[#F2C14E]/40 pb-3 mb-8 flex items-baseline justify-between">
                <h2
                  onClick={onHeadingClick}
                  className="text-2xl sm:text-3xl font-serif font-bold text-[#F2C14E] text-gold-radiant cursor-pointer hover:underline"
                  title="Bấm để xem cảnh báo"
                >
                  {t.tabOthers}
                </h2>
                <span className="text-xs text-stone-300">
                  {otherDishes.length} {lang === 'vi' ? 'món ăn kèm' : 'side items'}
                </span>
              </div>

              {/* Compact cards for quẩy, bánh mì, trứng chần */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                {otherDishes.map((dish) => (
                  <div
                    key={dish.id}
                    onClick={() => onSelectDish(dish)}
                    className="group bg-[#5d0202] border border-[#F2C14E]/30 hover:border-[#F2C14E] rounded-lg overflow-hidden cursor-pointer flex flex-col justify-between transition-all duration-200 hover:-translate-y-1 hover:shadow-lg"
                  >
                    <div className="relative aspect-16/10 overflow-hidden bg-stone-900">
                      <img
                        src={dish.image}
                        alt={dish.name[lang]}
                        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-black/80 text-xs font-mono font-bold text-[#F2C14E]">
                        {dish.formattedPrice} {t.vnd}
                      </div>
                    </div>

                    <div className="p-4">
                      <h3 className="text-sm font-serif font-bold text-[#F2C14E] group-hover:underline">
                        {dish.name[lang]}
                      </h3>
                      <p className="mt-1 text-xs text-stone-200 line-clamp-2">
                        {dish.shortDescription[lang]}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
      </div>
    </div>
  );
};
