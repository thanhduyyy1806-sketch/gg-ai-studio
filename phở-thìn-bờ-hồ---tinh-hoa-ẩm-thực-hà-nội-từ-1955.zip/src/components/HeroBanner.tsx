import React from 'react';
import { Language, PageView } from '../types';
import { translations } from '../data/translations';
import { CalendarCheck, Navigation, Award, Store, History } from 'lucide-react';

interface HeroBannerProps {
  lang: Language;
  onNavigate: (view: PageView) => void;
  onHeadingClick: () => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  lang,
  onNavigate,
  onHeadingClick,
}) => {
  const t = translations[lang].hero;

  return (
    <section className="relative min-h-[580px] lg:min-h-[640px] flex items-center justify-center bg-[#870505] overflow-hidden">
      {/* Background Hero Image with rich gradient overlays */}
      <div className="absolute inset-0 z-0">
        <img
          src="/src/assets/images/hero_pho_thin_bo_ho_1790702796317.jpg"
          alt="Phở Thìn Bờ Hồ Hà Nội"
          className="w-full h-full object-cover object-center brightness-60"
          referrerPolicy="no-referrer"
        />
        {/* Gradients to blend smoothly with Burgundy brand canvas */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#870505] via-[#870505]/70 to-[#5d0202]/70" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-transparent via-[#870505]/50 to-[#870505]" />
      </div>

      {/* Hero Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center flex flex-col items-center">
        {/* Heritage Pill Tag */}
        <div 
          onClick={onHeadingClick}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#5d0202]/90 border border-[#F2C14E]/80 text-[#F2C14E] text-xs uppercase tracking-widest font-semibold mb-6 shadow-md cursor-pointer hover:border-[#F2C14E] transition-all transform hover:scale-105"
          title="Bấm để xem cảnh báo mạo danh & bảo vệ bản quyền"
        >
          <span className="w-2 h-2 rounded-full bg-[#F2C14E] animate-pulse" />
          <span>{t.tagline}</span>
        </div>

        {/* Brand Display Headline (Clicking heading triggers map warning modal per requirement!) */}
        <h1
          onClick={onHeadingClick}
          className="text-3xl sm:text-4xl lg:text-5xl font-['Be_Vietnam_Pro'] font-extrabold tracking-normal text-[#F2C14E] text-gold-radiant max-w-4xl cursor-pointer hover:opacity-95 transition-opacity selection:text-[#1A1A1A] leading-tight"
          title="Bấm vào tiêu đề để xem cảnh báo giả mạo địa điểm bản đồ"
        >
          {t.heading}
        </h1>

        {/* Subtitle / Story Hook */}
        <p className="mt-5 text-sm sm:text-base lg:text-lg text-stone-200 max-w-2xl leading-relaxed font-normal">
          {t.subtext}
        </p>

        {/* 2 Primary CTA Buttons according to specification */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4 w-full sm:w-auto">
          {/* [Đặt bàn] - Gold background, black text */}
          <button
            onClick={() => onNavigate('reservation')}
            className="w-full sm:w-auto px-8 py-3.5 bg-[#F2C14E] text-[#1A1A1A] font-bold text-sm uppercase tracking-wider rounded shadow-xl hover:bg-[#ffe382] transform active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <CalendarCheck className="w-4 h-4 text-[#870505]" />
            <span>{t.btnReserve}</span>
          </button>

          {/* [Chỉ đường] - Elegant border with icon */}
          <button
            onClick={() => onNavigate('contact')}
            className="w-full sm:w-auto px-8 py-3.5 bg-black/40 hover:bg-black/60 border border-[#F2C14E] text-[#F2C14E] font-bold text-sm uppercase tracking-wider rounded backdrop-blur-sm transform active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Navigation className="w-4 h-4 text-[#F2C14E]" />
            <span>{t.btnDirections}</span>
          </button>
        </div>

        {/* Trust Badges Bar */}
        <div className="mt-12 grid grid-cols-3 gap-4 sm:gap-8 pt-8 border-t border-[#F2C14E]/30 w-full max-w-3xl">
          <div className="flex flex-col items-center">
            <History className="w-5 h-5 text-[#F2C14E] mb-1" />
            <span className="text-base sm:text-lg font-bold text-stone-100">{t.stats1955}</span>
            <span className="text-xs text-stone-300">70 năm giữ trọn vị</span>
          </div>
          <div className="flex flex-col items-center">
            <Store className="w-5 h-5 text-[#F2C14E] mb-1" />
            <span className="text-base sm:text-lg font-bold text-stone-100">{t.statsBranches}</span>
            <span className="text-xs text-stone-300">Hoàn Kiếm • BĐ • HBT</span>
          </div>
          <div className="flex flex-col items-center">
            <Award className="w-5 h-5 text-[#F2C14E] mb-1" />
            <span className="text-base sm:text-lg font-bold text-stone-100">{t.statsHeritage}</span>
            <span className="text-xs text-stone-300">Bí kíp ninh xương bò</span>
          </div>
        </div>
      </div>
    </section>
  );
};
