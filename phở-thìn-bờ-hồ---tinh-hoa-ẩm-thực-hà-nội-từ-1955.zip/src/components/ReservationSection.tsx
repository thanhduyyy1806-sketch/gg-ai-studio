import React, { useState, useEffect } from 'react';
import { Language, PageView, Branch, Dish, ReservationFormData, ReservationRecord } from '../types';
import { BRANCHES } from '../data/branches';
import { translations } from '../data/translations';
import { 
  Calendar, 
  Clock, 
  Users, 
  MapPin, 
  Phone, 
  Mail, 
  User, 
  MessageSquare, 
  CheckCircle2, 
  AlertCircle, 
  Printer, 
  Home, 
  Sparkles,
  Info
} from 'lucide-react';

interface ReservationSectionProps {
  lang: Language;
  onNavigate: (view: PageView) => void;
  onHeadingClick: () => void;
  preselectedDish?: Dish | null;
  initialBranchId?: string;
}

export const ReservationSection: React.FC<ReservationSectionProps> = ({
  lang,
  onNavigate,
  onHeadingClick,
  preselectedDish,
  initialBranchId,
}) => {
  const t = translations[lang].reservation;

  // Today in YYYY-MM-DD
  const todayStr = new Date().toISOString().split('T')[0];

  // Available Time Slots inside Opening Hours (06:00 - 13:00 and 17:00 - 22:00)
  const timeSlots = [
    // Morning: 06:00 – 13:00
    '06:30', '07:00', '07:30', '08:00', '08:30', '09:00', '09:30', 
    '10:00', '10:30', '11:00', '11:30', '12:00', '12:30',
    // Afternoon: 17:00 – 22:00
    '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', 
    '20:00', '20:30', '21:00', '21:30'
  ];

  // Form State
  const [formData, setFormData] = useState<ReservationFormData>({
    fullName: '',
    email: '',
    phone: '',
    reservationDate: todayStr,
    reservationTime: '11:30',
    partySize: 2,
    branchId: initialBranchId || 'cs1-dinh-tien-hoang',
    notes: preselectedDish 
      ? (lang === 'vi' ? `Muốn thưởng thức món: ${preselectedDish.name.vi}` : `Interested in ordering: ${preselectedDish.name[lang]}`)
      : '',
  });

  // Validation errors map
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [confirmation, setConfirmation] = useState<ReservationRecord | null>(null);

  useEffect(() => {
    if (initialBranchId) {
      setFormData((prev) => ({ ...prev, branchId: initialBranchId }));
    }
  }, [initialBranchId]);

  useEffect(() => {
    if (preselectedDish) {
      const dishNote = lang === 'vi' 
        ? `Muốn thưởng thức món: ${preselectedDish.name.vi}` 
        : `Interested in ordering: ${preselectedDish.name[lang]}`;
      setFormData((prev) => ({
        ...prev,
        notes: prev.notes ? `${prev.notes}. ${dishNote}` : dishNote
      }));
    }
  }, [preselectedDish, lang]);

  const selectedBranch = BRANCHES.find((b) => b.id === formData.branchId) || BRANCHES[0];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    // Clear specific field error when user modifies
    if (errors[name]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[name];
        return next;
      });
    }
  };

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    // 1. Tên bắt buộc
    if (!formData.fullName.trim()) {
      newErrors.fullName = t.errors.nameRequired;
    }

    // 2. Số điện thoại bắt buộc & đúng format Việt Nam
    if (!formData.phone.trim()) {
      newErrors.phone = t.errors.phoneRequired;
    } else {
      // Clean phone
      const cleanPhone = formData.phone.replace(/[\s\-\.\(\)]/g, '');
      const vnPhoneRegex = /(84|0[3|5|7|8|9])+([0-9]{8})\b/;
      if (!vnPhoneRegex.test(cleanPhone)) {
        newErrors.phone = t.errors.phoneInvalid;
      }
    }

    // 3. Ngày bắt buộc & không chọn ngày quá khứ
    if (!formData.reservationDate) {
      newErrors.reservationDate = t.errors.dateRequired;
    } else if (formData.reservationDate < todayStr) {
      newErrors.reservationDate = t.errors.datePast;
    }

    // 4. Giờ bắt buộc & trong giờ mở cửa
    if (!formData.reservationTime) {
      newErrors.reservationTime = t.errors.timeRequired;
    }

    // 5. Số lượng người >= 1
    if (!formData.partySize || Number(formData.partySize) < 1) {
      newErrors.partySize = t.errors.partySizeRequired;
    }

    // 6. Cơ sở bắt buộc
    if (!formData.branchId) {
      newErrors.branchId = t.errors.branchRequired;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      return;
    }

    setIsSubmitting(true);

    // Simulate sending reservation to the selected branch
    setTimeout(() => {
      setIsSubmitting(false);
      const code = `PTBH-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
      const record: ReservationRecord = {
        id: code,
        createdAt: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
        data: formData,
        branch: selectedBranch,
      };
      setConfirmation(record);
      window.scrollTo({ top: 100, behavior: 'smooth' });
    }, 700);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="py-10 sm:py-16 bg-[#870505] min-h-screen text-stone-100">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Navigation Breadcrumbs */}
        <div className="flex items-center gap-2 text-xs text-stone-300 mb-6">
          <button
            onClick={() => onNavigate('home')}
            className="hover:text-[#F2C14E] transition-colors cursor-pointer"
          >
            {translations[lang].nav.home}
          </button>
          <span>/</span>
          <span className="text-[#F2C14E] font-medium">{t.title}</span>
        </div>

        {/* STEP 6: SUCCESS CONFIRMATION VOUCHER */}
        {confirmation ? (
          <div className="bg-[#5d0202] border-2 border-[#F2C14E] rounded-2xl p-6 sm:p-10 shadow-2xl animate-in zoom-in-95 duration-300">
            <div className="text-center pb-6 border-b border-[#F2C14E]/30">
              <div className="w-16 h-16 bg-[#F2C14E] text-[#1A1A1A] rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <CheckCircle2 className="w-10 h-10 text-[#870505]" />
              </div>
              <h2 className="text-2xl sm:text-3xl font-serif font-black text-[#F2C14E] text-gold-radiant">
                {t.successTitle}
              </h2>
              <p className="mt-2 text-sm text-stone-200 max-w-lg mx-auto">
                {t.successSubtitle}
              </p>
              <div className="mt-4 inline-block bg-[#400101] border border-[#F2C14E] px-4 py-1.5 rounded text-xs font-mono font-bold text-[#F2C14E]">
                {t.bookingCode}: <span className="text-lg text-white ml-1">{confirmation.id}</span>
              </div>
            </div>

            {/* Summary Details */}
            <div className="py-6 grid grid-cols-1 md:grid-cols-2 gap-6 border-b border-[#F2C14E]/30">
              {/* Left Column: Customer details */}
              <div className="bg-[#420101] p-5 rounded-xl border border-[#F2C14E]/20 space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#F2C14E] flex items-center gap-2">
                  <User className="w-4 h-4" />
                  <span>{t.guestInfo}</span>
                </h3>
                <div className="text-sm space-y-2 text-stone-200">
                  <p><span className="text-stone-400">Họ tên:</span> <strong className="text-white">{confirmation.data.fullName}</strong></p>
                  <p><span className="text-stone-400">Số điện thoại:</span> <strong className="text-white">{confirmation.data.phone}</strong></p>
                  {confirmation.data.email && (
                    <p><span className="text-stone-400">Email:</span> {confirmation.data.email}</p>
                  )}
                  <p><span className="text-stone-400">Ngày đến:</span> <strong className="text-[#F2C14E]">{confirmation.data.reservationDate}</strong></p>
                  <p><span className="text-stone-400">Thời gian:</span> <strong className="text-[#F2C14E]">{confirmation.data.reservationTime}</strong></p>
                  <p><span className="text-stone-400">Số lượng khách:</span> <strong className="text-white">{confirmation.data.partySize} người</strong></p>
                  {confirmation.data.notes && (
                    <p className="text-xs bg-[#500202] p-2 rounded border border-stone-700 italic">
                      Ghi chú: "{confirmation.data.notes}"
                    </p>
                  )}
                </div>
              </div>

              {/* Right Column: Branch Info & Hotline */}
              <div className="bg-[#420101] p-5 rounded-xl border border-[#F2C14E]/20 space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#F2C14E] flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  <span>{t.branchInfo}</span>
                </h3>
                <div className="text-sm space-y-2 text-stone-200">
                  <p className="text-base font-serif font-bold text-[#F2C14E]">
                    {confirmation.branch.name[lang]}
                  </p>
                  <p className="text-xs text-stone-300">
                    {confirmation.branch.address}
                  </p>
                  <div className="mt-4 pt-3 border-t border-stone-700">
                    <span className="text-xs text-stone-400 block">{t.hotlineNotice}:</span>
                    <a 
                      href={`tel:${confirmation.branch.phone.replace(/[^0-9+]/g, '')}`}
                      className="text-lg font-mono font-bold text-[#F2C14E] hover:underline flex items-center gap-1.5 mt-1"
                    >
                      <Phone className="w-4 h-4" />
                      <span>{confirmation.branch.phone}</span>
                    </a>
                  </div>
                  <div className="text-xs text-stone-400 mt-2">
                    <span>{t.noticeTime}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
              <button
                onClick={handlePrint}
                className="w-full sm:w-auto px-5 py-2.5 bg-[#420101] hover:bg-[#500202] border border-stone-500 text-stone-200 font-semibold text-xs uppercase tracking-wider rounded flex items-center justify-center gap-2 cursor-pointer transition-colors"
              >
                <Printer className="w-4 h-4" />
                <span>{t.btnPrint}</span>
              </button>

              <button
                onClick={() => {
                  setConfirmation(null);
                  onNavigate('home');
                }}
                className="w-full sm:w-auto px-8 py-3 bg-[#F2C14E] text-[#1A1A1A] font-bold text-xs uppercase tracking-wider rounded shadow-lg hover:bg-[#ffe380] flex items-center justify-center gap-2 cursor-pointer transition-colors"
              >
                <Home className="w-4 h-4" />
                <span>{t.btnBackHome}</span>
              </button>
            </div>
          </div>
        ) : (
          /* STEP 4 & 5: RESERVATION FORM */
          <div className="bg-[#5d0202] border-2 border-[#F2C14E]/60 rounded-2xl shadow-2xl p-6 sm:p-10">
            {/* Header */}
            <div className="text-center max-w-xl mx-auto mb-8">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-[#870505] border border-[#F2C14E]/60 text-[#F2C14E] text-xs font-semibold uppercase tracking-wider mb-2">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Đặt Chỗ Trực Tiếp Không Qua Trung Gian</span>
              </span>
              <h1
                onClick={onHeadingClick}
                className="text-2xl sm:text-3xl font-serif font-black text-[#F2C14E] text-gold-radiant cursor-pointer hover:opacity-95"
                title="Bấm để xem cảnh báo giả mạo bản đồ"
              >
                {t.title}
              </h1>
              <p className="mt-2 text-xs sm:text-sm text-stone-300">
                {t.subtitle}
              </p>
              <div className="mt-3 inline-flex items-center gap-2 px-3 py-1 rounded bg-[#400101] border border-[#F2C14E]/40 text-xs text-[#F2C14E]">
                <Clock className="w-3.5 h-3.5" />
                <span>{t.noticeTime}</span>
              </div>
            </div>

            {/* If dish was pre-selected, show notice */}
            {preselectedDish && (
              <div className="mb-6 p-4 rounded-xl bg-[#400101] border border-[#F2C14E] flex items-center gap-3">
                <img
                  src={preselectedDish.image}
                  alt={preselectedDish.name[lang]}
                  className="w-12 h-12 rounded object-cover border border-[#F2C14E]/50"
                  referrerPolicy="no-referrer"
                />
                <div className="flex-1">
                  <span className="text-[11px] uppercase tracking-wider text-[#F2C14E] font-bold block">
                    {lang === 'vi' ? 'Món ăn đã chọn thưởng thức:' : 'Selected Dish to Enjoy:'}
                  </span>
                  <span className="text-sm font-serif font-bold text-white">
                    {preselectedDish.name[lang]} ({preselectedDish.formattedPrice}đ)
                  </span>
                </div>
              </div>
            )}

            {/* The 8 Form Fields */}
            <form onSubmit={handleSubmit} className="space-y-6" noValidate>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* 1. Họ và tên * (Bắt buộc) */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#F2C14E] mb-2">
                    {t.fieldName} <span className="text-red-400">*</span>
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-stone-400 absolute left-3.5 top-3.5" />
                    <input
                      type="text"
                      name="fullName"
                      value={formData.fullName}
                      onChange={handleInputChange}
                      placeholder={t.placeholderName}
                      className={`w-full pl-10 pr-4 py-2.5 bg-[#400101] border rounded-lg text-sm text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-[#F2C14E] transition-all ${
                        errors.fullName ? 'border-red-500 ring-1 ring-red-500' : 'border-[#F2C14E]/40'
                      }`}
                    />
                  </div>
                  {errors.fullName && (
                    <p className="mt-1 text-xs text-red-400 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{errors.fullName}</span>
                    </p>
                  )}
                </div>

                {/* 2. Số điện thoại * (Bắt buộc & Validate định dạng VN) */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#F2C14E] mb-2">
                    {t.fieldPhone} <span className="text-red-400">*</span>
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-stone-400 absolute left-3.5 top-3.5" />
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder={t.placeholderPhone}
                      className={`w-full pl-10 pr-4 py-2.5 bg-[#400101] border rounded-lg text-sm text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-[#F2C14E] transition-all ${
                        errors.phone ? 'border-red-500 ring-1 ring-red-500' : 'border-[#F2C14E]/40'
                      }`}
                    />
                  </div>
                  {errors.phone && (
                    <p className="mt-1 text-xs text-red-400 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{errors.phone}</span>
                    </p>
                  )}
                </div>

                {/* 3. Email (Không bắt buộc) */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#F2C14E] mb-2">
                    {t.fieldEmail}
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-stone-400 absolute left-3.5 top-3.5" />
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder={t.placeholderEmail}
                      className="w-full pl-10 pr-4 py-2.5 bg-[#400101] border border-[#F2C14E]/40 rounded-lg text-sm text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-[#F2C14E] transition-all"
                    />
                  </div>
                </div>

                {/* 4. Số lượng người * (Bắt buộc, nguyên dương) */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#F2C14E] mb-2">
                    {t.fieldPartySize} <span className="text-red-400">*</span>
                  </label>
                  <div className="relative">
                    <Users className="w-4 h-4 text-stone-400 absolute left-3.5 top-3.5" />
                    <input
                      type="number"
                      name="partySize"
                      min="1"
                      max="50"
                      value={formData.partySize}
                      onChange={handleInputChange}
                      className={`w-full pl-10 pr-4 py-2.5 bg-[#400101] border rounded-lg text-sm text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-[#F2C14E] transition-all ${
                        errors.partySize ? 'border-red-500 ring-1 ring-red-500' : 'border-[#F2C14E]/40'
                      }`}
                    />
                  </div>
                  {errors.partySize && (
                    <p className="mt-1 text-xs text-red-400 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{errors.partySize}</span>
                    </p>
                  )}
                </div>

                {/* 5. Ngày đặt bàn * (Bắt buộc, không quá khứ) */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#F2C14E] mb-2">
                    {t.fieldDate} <span className="text-red-400">*</span>
                  </label>
                  <div className="relative">
                    <Calendar className="w-4 h-4 text-stone-400 absolute left-3.5 top-3.5 pointer-events-none" />
                    <input
                      type="date"
                      name="reservationDate"
                      min={todayStr}
                      value={formData.reservationDate}
                      onChange={handleInputChange}
                      className={`w-full pl-10 pr-4 py-2.5 bg-[#400101] border rounded-lg text-sm text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-[#F2C14E] transition-all ${
                        errors.reservationDate ? 'border-red-500 ring-1 ring-red-500' : 'border-[#F2C14E]/40'
                      }`}
                    />
                  </div>
                  {errors.reservationDate && (
                    <p className="mt-1 text-xs text-red-400 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{errors.reservationDate}</span>
                    </p>
                  )}
                </div>

                {/* 6. Thời gian đến * (Bắt buộc, trong giờ mở cửa 06-13 & 17-22) */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#F2C14E] mb-2">
                    {t.fieldTime} <span className="text-red-400">*</span>
                  </label>
                  <div className="relative">
                    <Clock className="w-4 h-4 text-stone-400 absolute left-3.5 top-3.5 pointer-events-none" />
                    <select
                      name="reservationTime"
                      value={formData.reservationTime}
                      onChange={handleInputChange}
                      className={`w-full pl-10 pr-4 py-2.5 bg-[#400101] border rounded-lg text-sm text-stone-100 focus:outline-none focus:ring-2 focus:ring-[#F2C14E] transition-all ${
                        errors.reservationTime ? 'border-red-500 ring-1 ring-red-500' : 'border-[#F2C14E]/40'
                      }`}
                    >
                      <optgroup label="Khung Giờ Sáng (06:00 – 13:00)">
                        {timeSlots.slice(0, 13).map((slot) => (
                          <option key={slot} value={slot}>{slot}</option>
                        ))}
                      </optgroup>
                      <optgroup label="Khung Giờ Chiều (17:00 – 22:00)">
                        {timeSlots.slice(13).map((slot) => (
                          <option key={slot} value={slot}>{slot}</option>
                        ))}
                      </optgroup>
                    </select>
                  </div>
                  {errors.reservationTime && (
                    <p className="mt-1 text-xs text-red-400 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{errors.reservationTime}</span>
                    </p>
                  )}
                </div>
              </div>

              {/* 7. Chọn cơ sở * (Bắt buộc, 4 cơ sở) */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#F2C14E] mb-2">
                  {t.fieldBranch} <span className="text-red-400">*</span>
                </label>
                <div className="relative">
                  <MapPin className="w-4 h-4 text-stone-400 absolute left-3.5 top-3.5 pointer-events-none" />
                  <select
                    name="branchId"
                    value={formData.branchId}
                    onChange={handleInputChange}
                    className={`w-full pl-10 pr-4 py-2.5 bg-[#400101] border rounded-lg text-sm text-stone-100 focus:outline-none focus:ring-2 focus:ring-[#F2C14E] transition-all ${
                      errors.branchId ? 'border-red-500 ring-1 ring-red-500' : 'border-[#F2C14E]/40'
                    }`}
                  >
                    {BRANCHES.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.code}: {b.name[lang]} {b.isOriginal ? '★ [Bờ Hồ Gốc 1955]' : ''}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Instant preview of selected branch address & phone as instructed in brief */}
                {selectedBranch && (
                  <div className="mt-3 p-3.5 rounded-lg bg-[#400101] border border-[#F2C14E]/40 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                    <div>
                      <span className="text-stone-400 block">Địa chỉ phục vụ:</span>
                      <strong className="text-stone-100">{selectedBranch.address}</strong>
                    </div>
                    <div className="shrink-0 flex items-center gap-1.5 text-[#F2C14E] font-mono font-bold">
                      <Phone className="w-3.5 h-3.5" />
                      <a href={`tel:${selectedBranch.phone.replace(/[^0-9+]/g, '')}`} className="hover:underline">
                        {selectedBranch.phone}
                      </a>
                    </div>
                  </div>
                )}
              </div>

              {/* 8. Lời nhắn / Ghi chú (Không bắt buộc) */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#F2C14E] mb-2">
                  {t.fieldNotes}
                </label>
                <div className="relative">
                  <MessageSquare className="w-4 h-4 text-stone-400 absolute left-3.5 top-3.5" />
                  <textarea
                    rows={3}
                    name="notes"
                    value={formData.notes}
                    onChange={handleInputChange}
                    placeholder={t.placeholderNotes}
                    className="w-full pl-10 pr-4 py-2.5 bg-[#400101] border border-[#F2C14E]/40 rounded-lg text-sm text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-[#F2C14E] transition-all resize-none"
                  />
                </div>
              </div>

              {/* Action Submit Button [Gửi thông tin] */}
              <div className="pt-4">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 bg-[#F2C14E] hover:bg-[#ffe380] text-[#1A1A1A] font-bold text-sm uppercase tracking-wider rounded-lg shadow-xl transform active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <span>{t.btnSubmitting}</span>
                  ) : (
                    <>
                      <CheckCircle2 className="w-5 h-5 text-[#870505]" />
                      <span>{t.btnSubmit}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
