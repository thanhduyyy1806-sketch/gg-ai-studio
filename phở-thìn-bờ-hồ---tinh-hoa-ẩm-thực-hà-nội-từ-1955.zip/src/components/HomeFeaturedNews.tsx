import React from 'react';
import { Language, PageView, Article } from '../types';
import { ARTICLES } from '../data/news';
import { translations } from '../data/translations';
import { Newspaper, Calendar, Clock, ArrowRight, Sparkles, Image as ImageIcon } from 'lucide-react';

interface HomeFeaturedNewsProps {
  lang: Language;
  onNavigate: (view: PageView) => void;
  onSelectArticle: (article: Article) => void;
  onHeadingClick: () => void;
}

export const HomeFeaturedNews: React.FC<HomeFeaturedNewsProps> = ({
  lang,
  onNavigate,
  onSelectArticle,
  onHeadingClick,
}) => {
  const t = translations[lang].featuredNews;
  // 3 featured news matching the Canva design
  const featuredArticles = ARTICLES.slice(0, 3);

  return (
    <section className="py-16 sm:py-24 bg-[#870505] text-stone-100 border-b border-[#F2C14E]/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 sm:mb-16 gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-[#5d0202] border border-[#F2C14E]/60 text-[#F2C14E] text-xs font-semibold uppercase tracking-wider mb-3">
              <Newspaper className="w-3.5 h-3.5" />
              <span>Góc Tin Tức & Di Sản Văn Hoá</span>
            </div>
            <h2
              onClick={onHeadingClick}
              className="text-2xl sm:text-3xl lg:text-4xl font-serif font-bold text-[#F2C14E] text-gold-radiant cursor-pointer hover:opacity-95 transition-opacity"
              title="Bấm để xem cảnh báo mạo danh & bảo vệ bản quyền"
            >
              {t.title}
            </h2>
            <p className="mt-2 text-sm text-stone-300">
              {t.subtitle}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('news')}
              className="inline-flex items-center gap-2 px-4 py-2 bg-[#5d0202] hover:bg-[#F2C14E] text-[#F2C14E] hover:text-[#1A1A1A] border border-[#F2C14E]/70 rounded-lg text-xs sm:text-sm font-bold transition-all shadow-md cursor-pointer"
            >
              <ImageIcon className="w-4 h-4" />
              <span>{lang === 'vi' ? 'Xem Bảng Tin Thiết Kế (9 bài)' : 'View Canva News Board (9 articles)'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 3 Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredArticles.map((article, idx) => (
            <article
              key={article.id}
              className="group bg-[#5d0202] border border-[#F2C14E]/30 hover:border-[#F2C14E] rounded-xl overflow-hidden flex flex-col justify-between transition-all duration-300 hover:-translate-y-1.5 hover:shadow-2xl"
            >
              <div>
                <div className="relative aspect-16/10 overflow-hidden bg-stone-900">
                  <img
                    src={idx === 0 ? '/news/news-article-chinsu.png' : article.image}
                    alt={article.title[lang]}
                    className={`w-full h-full transition-transform duration-500 group-hover:scale-105 ${
                      idx === 0 ? 'object-cover object-top' : 'object-cover'
                    }`}
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-3 left-3 bg-[#870505]/95 border border-[#F2C14E]/60 text-[#F2C14E] text-[10px] font-bold px-2.5 py-0.5 rounded shadow">
                    {article.category[lang]}
                  </div>

                  {idx === 0 && (
                    <div className="absolute bottom-3 right-3 bg-[#F2C14E] text-[#1A1A1A] text-[10px] font-extrabold px-2 py-0.5 rounded shadow flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-[#870505]" />
                      <span>Nổi bật nhất</span>
                    </div>
                  )}
                </div>

                <div className="p-5">
                  <div className="flex items-center gap-3 text-xs text-stone-300 mb-2">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-[#F2C14E]" />
                      {article.date}
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-[#F2C14E]" />
                      {article.readTime}
                    </span>
                  </div>

                  <h3
                    onClick={(e) => {
                      e.stopPropagation();
                      onHeadingClick();
                    }}
                    className="text-base sm:text-lg font-serif font-bold text-[#F2C14E] group-hover:text-[#ffe285] transition-colors leading-snug line-clamp-2 cursor-pointer hover:underline"
                    title="Bấm vào tiêu đề để xem cảnh báo"
                  >
                    {article.title[lang]}
                  </h3>

                  <p className="mt-2 text-xs sm:text-sm text-stone-300 line-clamp-3 leading-relaxed">
                    {article.excerpt[lang]}
                  </p>
                </div>
              </div>

              <div className="p-5 pt-0">
                <button
                  onClick={() => onSelectArticle(article)}
                  className="w-full py-2.5 px-3 bg-[#870505] hover:bg-[#F2C14E] text-[#F2C14E] hover:text-[#1A1A1A] border border-[#F2C14E]/60 text-xs font-bold uppercase tracking-wider rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow"
                >
                  <span>{t.btnViewDetail}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};
