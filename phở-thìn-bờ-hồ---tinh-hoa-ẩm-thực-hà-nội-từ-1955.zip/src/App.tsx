import React, { useState } from 'react';
import { Language, PageView, Dish, Article } from './types';
import { Navbar } from './components/Navbar';
import { LoadingScreen } from './components/LoadingScreen';
import { FakeMapWarningModal } from './components/FakeMapWarningModal';
import { HeroBanner } from './components/HeroBanner';
import { HomeIntroCards } from './components/HomeIntroCards';
import { HomeFeaturedDishes } from './components/HomeFeaturedDishes';
import { HomeFeaturedNews } from './components/HomeFeaturedNews';
import { AboutNewspaper } from './components/AboutNewspaper';
import { MenuSection } from './components/MenuSection';
import { DishDetailModal } from './components/DishDetailModal';
import { ReservationSection } from './components/ReservationSection';
import { NewsSection } from './components/NewsSection';
import { PartnerSection } from './components/PartnerSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';

export default function App() {
  // Step 0: Loading screen with steaming pho bowl
  const [isLoading, setIsLoading] = useState(true);

  // Active view page ('home' | 'about' | 'menu' | 'reservation' | 'news' | 'partners' | 'contact')
  const [currentView, setCurrentView] = useState<PageView>('home');

  // Selected language: vi, en, zh, ko
  const [lang, setLang] = useState<Language>('vi');

  // Dish details modal
  const [selectedDish, setSelectedDish] = useState<Dish | null>(null);

  // Reservation pre-selected parameters
  const [dishForReservation, setDishForReservation] = useState<Dish | null>(null);
  const [branchForReservation, setBranchForReservation] = useState<string | undefined>(undefined);

  // Article details
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);

  // Impersonation & Fake Map Warning modal
  // "Mỗi lần bấm vào một heading sẽ hiện cảnh báo giả mạo bản đồ"
  const [isWarningOpen, setIsWarningOpen] = useState(false);

  const handleHeadingClick = () => {
    setIsWarningOpen(true);
  };

  const handleNavigate = (view: PageView) => {
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectDish = (dish: Dish) => {
    setSelectedDish(dish);
  };

  const handleReserveWithDish = (dish: Dish) => {
    setDishForReservation(dish);
    setSelectedDish(null);
    setCurrentView('reservation');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleReserveBranch = (branchId: string) => {
    setBranchForReservation(branchId);
    setCurrentView('reservation');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectArticle = (article: Article | null) => {
    setSelectedArticle(article);
    if (article) {
      setCurrentView('news');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#870505] text-stone-100 flex flex-col font-sans selection:bg-[#F2C14E] selection:text-[#1A1A1A]">
      {/* Step 0: Initial Steam Loading Screen */}
      {isLoading && (
        <LoadingScreen lang={lang} onFinish={() => setIsLoading(false)} />
      )}

      {/* Persistent Top Navigation Bar (Zone 1: Brand Wordmark, Zone 2: Links, Zone 3: Language & [Đặt bàn]) */}
      <Navbar
        currentView={currentView}
        onNavigate={handleNavigate}
        lang={lang}
        onLanguageChange={setLang}
        onTriggerWarning={() => setIsWarningOpen(true)}
      />

      {/* Main Content Area based on current view */}
      <main className="flex-1">
        {/* VIEW 1: HOME PAGE */}
        {currentView === 'home' && (
          <>
            {/* Banner: Tên quán + Slogan + [Đặt bàn] [Chỉ đường] */}
            <HeroBanner
              lang={lang}
              onNavigate={handleNavigate}
              onHeadingClick={handleHeadingClick}
            />

            {/* 4 Thẻ giới thiệu */}
            <HomeIntroCards
              lang={lang}
              onNavigate={handleNavigate}
              onHeadingClick={handleHeadingClick}
            />

            {/* 5 Món nổi bật (Phở tái chín ở giữa có nhãn SIGNATURE) */}
            <HomeFeaturedDishes
              lang={lang}
              onNavigate={handleNavigate}
              onSelectDish={handleSelectDish}
              onHeadingClick={handleHeadingClick}
            />

            {/* Khối Bảng tin nổi bật */}
            <HomeFeaturedNews
              lang={lang}
              onNavigate={handleNavigate}
              onSelectArticle={handleSelectArticle}
              onHeadingClick={handleHeadingClick}
            />
          </>
        )}

        {/* VIEW 2: GIỚI THIỆU - PHONG CÁCH BÁO CŨ (Vàng cổ #F3E3B3, Chữ đỏ đô #870505) */}
        {currentView === 'about' && (
          <AboutNewspaper
            lang={lang}
            onNavigate={handleNavigate}
            onHeadingClick={handleHeadingClick}
          />
        )}

        {/* VIEW 3: THỰC ĐƠN (Phở -> Đồ uống -> Khác) */}
        {currentView === 'menu' && (
          <MenuSection
            lang={lang}
            onNavigate={handleNavigate}
            onSelectDish={handleSelectDish}
            onHeadingClick={handleHeadingClick}
          />
        )}

        {/* VIEW 4 & 5: ĐIỀN FORM ĐẶT BÀN & XÁC NHẬN */}
        {currentView === 'reservation' && (
          <ReservationSection
            lang={lang}
            onNavigate={handleNavigate}
            onHeadingClick={handleHeadingClick}
            preselectedDish={dishForReservation}
            initialBranchId={branchForReservation}
          />
        )}

        {/* VIEW 5: BẢNG TIN (2 trang tin: 5 mục & 4 mục, chi tiết bài) */}
        {currentView === 'news' && (
          <NewsSection
            lang={lang}
            onNavigate={handleNavigate}
            onHeadingClick={handleHeadingClick}
            selectedArticle={selectedArticle}
            onSelectArticle={setSelectedArticle}
          />
        )}

        {/* VIEW 6: ĐỐI TÁC (Masan Chin-su Phở Story) */}
        {currentView === 'partners' && (
          <PartnerSection
            lang={lang}
            onNavigate={handleNavigate}
            onHeadingClick={handleHeadingClick}
          />
        )}

        {/* VIEW 7: LIÊN HỆ & TUYỂN DỤNG */}
        {currentView === 'contact' && (
          <ContactSection
            lang={lang}
            onNavigate={handleNavigate}
            onHeadingClick={handleHeadingClick}
            onReserveBranch={handleReserveBranch}
          />
        )}
      </main>

      {/* Modal View: Step 3 - Dish Detail (Ảnh lớn, Giá, Mô tả, Nguyên liệu, Món cùng loại, [Đặt bàn]) */}
      <DishDetailModal
        dish={selectedDish}
        isOpen={Boolean(selectedDish)}
        onClose={() => setSelectedDish(null)}
        lang={lang}
        onNavigate={handleNavigate}
        onReserveWithDish={handleReserveWithDish}
        onSelectDish={handleSelectDish}
      />

      {/* Modal View: Cảnh Báo Mạo Danh & Bản Đồ Giả Mạo Phở Thìn Bờ Hồ */}
      <FakeMapWarningModal
        isOpen={isWarningOpen}
        onClose={() => setIsWarningOpen(false)}
        lang={lang}
        onNavigate={handleNavigate}
      />

      {/* Footer: 4 cơ sở, kênh kết nối, thông tin pháp lý, bản quyền */}
      <Footer
        lang={lang}
        onNavigate={handleNavigate}
        onHeadingClick={handleHeadingClick}
        onReserveBranch={handleReserveBranch}
      />
    </div>
  );
}
